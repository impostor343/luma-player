package com.lumaplayer.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.RateReview
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import com.lumaplayer.app.data.db.ReviewFolderEntity
import com.lumaplayer.app.data.db.VideoEntity
import com.lumaplayer.app.data.prefs.AppPreferences
import com.lumaplayer.app.data.prefs.PlayerLabConfig
import com.lumaplayer.app.domain.PlayerLabValidator
import com.lumaplayer.app.domain.ReviewThresholdConfig
import com.lumaplayer.app.domain.ReviewTriggerEngine
import com.lumaplayer.app.ui.history.HistoryScreen
import com.lumaplayer.app.ui.info.VideoInfoScreen
import com.lumaplayer.app.ui.library.FoldersScreen
import com.lumaplayer.app.ui.library.HomeScreen
import com.lumaplayer.app.ui.player.PlayerScreen
import com.lumaplayer.app.ui.reviews.ReviewPromptDialog
import com.lumaplayer.app.ui.reviews.ReviewsScreen
import com.lumaplayer.app.ui.settings.PlayerLabScreen
import com.lumaplayer.app.ui.settings.SettingsScreen
import com.lumaplayer.app.ui.theme.LumaPlayerTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    FOLDERS("Folders", Icons.Rounded.Folder),
    REVIEWS("Reviews", Icons.Rounded.RateReview),
    HISTORY("History", Icons.Rounded.History),
    SETTINGS("Settings", Icons.Rounded.Settings)
}

@Serializable
private data class ReviewsBackupPayload(
    val exportedAtMs: Long,
    val folderNames: List<String>,
    val reviews: List<ReviewBackupItem>
)

@Serializable
private data class ReviewBackupItem(
    val videoTitle: String,
    val rating: Int,
    val writtenReview: String,
    val notes: String,
    val tags: String,
    val folderName: String?,
    val dateWatchedMs: Long,
    val dateReviewedMs: Long
)

class MainActivity : ComponentActivity() {

    private var isInPipState by mutableStateOf(false)
    private var incomingExternalUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        setContent {
            LumaPlayerRoot(
                app = application as LumaApplication,
                isInPipMode = isInPipState,
                incomingUri = incomingExternalUri,
                onConsumedIncomingUri = { incomingExternalUri = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipState = isInPictureInPictureMode
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            incomingExternalUri = intent.data
        }
    }
}

@Composable
private fun LumaPlayerRoot(
    app: LumaApplication,
    isInPipMode: Boolean,
    incomingUri: Uri?,
    onConsumedIncomingUri: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val prefs by app.preferences.preferencesFlow.collectAsState(initial = AppPreferences())
    val allVideos by app.database.videoDao().observeAllVideos().collectAsState(initial = emptyList())
    val continueWatching by app.database.videoDao().observeContinueWatching().collectAsState(initial = emptyList())
    val recentlyPlayed by app.database.videoDao().observeRecentlyPlayed().collectAsState(initial = emptyList())
    val allSessions by app.database.playbackLogDao().observeAllSessions().collectAsState(initial = emptyList())
    val allReviews by app.database.reviewDao().observeAllReviews().collectAsState(initial = emptyList())
    val reviewFolders by app.database.reviewDao().observeFolders().collectAsState(initial = emptyList())

    var activeTab by remember { mutableStateOf(MainTab.HOME) }
    var selectedFolderPath by remember { mutableStateOf<String?>(null) }
    var activePlayerVideo by remember { mutableStateOf<VideoEntity?>(null) }
    var activeInfoVideoUid by remember { mutableStateOf<String?>(null) }
    var showPlayerLab by remember { mutableStateOf(false) }
    var pendingReviewVideo by remember { mutableStateOf<VideoEntity?>(null) }
    var isScanning by remember { mutableStateOf(false) }
    var pendingExportLabConfig by remember { mutableStateOf<PlayerLabConfig?>(null) }

    val requiredPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    var hasStoragePermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(app, requiredPermission) == PackageManager.PERMISSION_GRANTED
        )
    }

    fun triggerScan() {
        if (isScanning) return
        scope.launch {
            isScanning = true
            runCatching {
                app.libraryScanner.scanAll(
                    safFolderUris = prefs.safFolderUris,
                    includeHiddenFolders = prefs.showHiddenFolders
                )
            }
            isScanning = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasStoragePermission = granted
        if (granted) triggerScan()
    }

    val openVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            scope.launch {
                val entity = app.libraryScanner.registerExternalUri(uri)
                activePlayerVideo = entity
            }
        }
    }

    val addSafFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                app.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            scope.launch {
                app.preferences.update { it.copy(safFolderUris = it.safFolderUris + treeUri.toString()) }
                triggerScan()
            }
        }
    }

    val exportLabLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        val config = pendingExportLabConfig ?: return@rememberLauncherForActivityResult
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                runCatching {
                    val text = app.preferences.exportPlayerLabJson(config)
                    app.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(app, "Player Lab configuration exported", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val importLabLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val raw = runCatching {
                    app.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                }.getOrNull()
                val parsed = raw?.let { app.preferences.parsePlayerLabJson(it).getOrNull() }
                val validation = parsed?.let { PlayerLabValidator.validate(it) }
                if (parsed != null && validation?.isValid == true) {
                    app.preferences.update { it.copy(playerLab = parsed) }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(app, "Player Lab configuration imported", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        val reason = validation?.errors?.firstOrNull() ?: "Invalid JSON format"
                        Toast.makeText(app, "Import failed: $reason", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    val exportReviewsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val folderMap = reviewFolders.associate { it.folderId to it.name }
                val payload = ReviewsBackupPayload(
                    exportedAtMs = System.currentTimeMillis(),
                    folderNames = reviewFolders.map { it.name },
                    reviews = allReviews.map { r ->
                        ReviewBackupItem(
                            videoTitle = r.videoTitleSnapshot,
                            rating = r.rating,
                            writtenReview = r.writtenReview,
                            notes = r.notes,
                            tags = r.tags,
                            folderName = r.folderId?.let { folderMap[it] },
                            dateWatchedMs = r.dateWatchedMs,
                            dateReviewedMs = r.dateReviewedMs
                        )
                    }
                )
                val prettyJson = Json { prettyPrint = true }.encodeToString(payload)
                runCatching {
                    app.contentResolver.openOutputStream(uri)?.use { it.write(prettyJson.toByteArray()) }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(app, "Reviews backup exported", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Initial scan on launch if permission is granted
    LaunchedEffect(hasStoragePermission) {
        if (hasStoragePermission) {
            triggerScan()
        }
    }

    // Handle external ACTION_VIEW video intents
    LaunchedEffect(incomingUri) {
        if (incomingUri != null) {
            val entity = app.libraryScanner.registerExternalUri(incomingUri)
            activePlayerVideo = entity
            onConsumedIncomingUri()
        }
    }

    val availableUids = remember(allVideos) { allVideos.filter { it.isAvailable }.map { it.uid }.toSet() }

    LumaPlayerTheme(
        themeMode = prefs.themeMode,
        accentPreset = prefs.accentPreset,
        textScale = prefs.uiTextScale
    ) {
        when {
            activePlayerVideo != null -> {
                val playingVideo = activePlayerVideo!!
                val folderPlaylist = remember(allVideos, playingVideo.folderPath) {
                    allVideos.filter { it.isAvailable && it.folderPath == playingVideo.folderPath }
                        .sortedBy { it.displayName.lowercase() }
                }
                PlayerScreen(
                    video = playingVideo,
                    playlist = folderPlaylist,
                    prefs = prefs,
                    isInPipMode = isInPipMode,
                    onSaveBrightness = { b ->
                        scope.launch { app.preferences.update { it.copy(savedVideoBrightness = b) } }
                    },
                    onOpenVideoInfo = { v ->
                        activePlayerVideo = null
                        activeInfoVideoUid = v.uid
                    },
                    onSwitchVideo = { next ->
                        activePlayerVideo = next
                    },
                    onExitPlayer = { exitPos, duration, completed ->
                        activePlayerVideo = null
                        scope.launch {
                            val alreadyReviewed = app.database.reviewDao().countReviewsForVideo(playingVideo.uid) > 0
                            val freshVideo = app.database.videoDao().getVideoByUid(playingVideo.uid) ?: playingVideo
                            val shouldPrompt = ReviewTriggerEngine.shouldPromptForReview(
                                durationMs = duration,
                                exitPositionMs = exitPos,
                                completedNormally = completed,
                                alreadyReviewed = alreadyReviewed,
                                previouslyDismissed = freshVideo.reviewDismissed,
                                config = ReviewThresholdConfig(
                                    autoPromptEnabled = prefs.autoReviewPromptEnabled,
                                    longVideoRemainingMinutes = prefs.reviewThresholdLongVideoMin,
                                    mediumVideoRemainingMinutes = prefs.reviewThresholdMediumVideoMin,
                                    shortVideoMinPercent = prefs.reviewThresholdShortVideoPercent
                                )
                            )
                            if (shouldPrompt) {
                                pendingReviewVideo = freshVideo
                            }
                        }
                    }
                )
            }

            activeInfoVideoUid != null -> {
                val uid = activeInfoVideoUid!!
                val infoVideo by app.database.videoDao().observeVideoByUid(uid).collectAsState(initial = null)
                val videoSessions by app.database.playbackLogDao().observeSessionsForVideo(uid).collectAsState(initial = emptyList())
                val videoEvents by app.database.playbackLogDao().observeEventsForVideo(uid).collectAsState(initial = emptyList())
                val eventsBySession = remember(videoEvents) { videoEvents.groupBy { it.sessionId } }

                VideoInfoScreen(
                    video = infoVideo,
                    sessions = videoSessions,
                    eventsBySession = eventsBySession,
                    onBack = { activeInfoVideoUid = null },
                    onPlay = { v ->
                        activeInfoVideoUid = null
                        activePlayerVideo = v
                    },
                    onToggleFavourite = { v ->
                        scope.launch { app.database.videoDao().setFavourite(v.uid, !v.isFavourite) }
                    },
                    onWriteReview = { v ->
                        pendingReviewVideo = v
                    }
                )
            }

            showPlayerLab -> {
                PlayerLabScreen(
                    savedConfig = prefs.playerLab,
                    onSaveConfig = { cfg ->
                        scope.launch {
                            app.preferences.update { it.copy(playerLab = cfg) }
                            Toast.makeText(app, "Player Lab configuration saved", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onExportConfig = { cfg ->
                        pendingExportLabConfig = cfg
                        exportLabLauncher.launch("lumaplayer_lab_config.json")
                    },
                    onImportConfig = {
                        importLabLauncher.launch(arrayOf("application/json", "text/plain"))
                    },
                    onBack = { showPlayerLab = false }
                )
            }

            else -> {
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            MainTab.entries.forEach { tab ->
                                NavigationBarItem(
                                    selected = activeTab == tab,
                                    onClick = {
                                        activeTab = tab
                                        if (tab != MainTab.FOLDERS) selectedFolderPath = null
                                    },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = innerPadding.calculateBottomPadding())
                    ) {
                        when (activeTab) {
                            MainTab.HOME -> HomeScreen(
                                allVideos = allVideos,
                                continueWatching = continueWatching,
                                recentlyPlayed = recentlyPlayed,
                                prefs = prefs,
                                hasStoragePermission = hasStoragePermission,
                                isScanning = isScanning,
                                thumbnailLoader = app.thumbnailLoader,
                                onRequestPermission = { permissionLauncher.launch(requiredPermission) },
                                onRescan = { triggerScan() },
                                onToggleGrid = {
                                    scope.launch { app.preferences.update { it.copy(gridViewEnabled = !it.gridViewEnabled) } }
                                },
                                onChangeSort = { order ->
                                    scope.launch { app.preferences.update { it.copy(sortOrder = order) } }
                                },
                                onOpenVideoPicker = { openVideoLauncher.launch(arrayOf("video/*")) },
                                onPlayVideo = { v -> activePlayerVideo = v },
                                onOpenInfo = { v -> activeInfoVideoUid = v.uid },
                                onOpenFolder = { path ->
                                    selectedFolderPath = path
                                    activeTab = MainTab.FOLDERS
                                }
                            )

                            MainTab.FOLDERS -> FoldersScreen(
                                allVideos = allVideos,
                                selectedFolderPath = selectedFolderPath,
                                thumbnailLoader = app.thumbnailLoader,
                                onSelectFolder = { selectedFolderPath = it },
                                onAddSafFolder = { addSafFolderLauncher.launch(null) },
                                onPlayVideo = { v -> activePlayerVideo = v },
                                onOpenInfo = { v -> activeInfoVideoUid = v.uid }
                            )

                            MainTab.REVIEWS -> ReviewsScreen(
                                reviews = allReviews,
                                folders = reviewFolders,
                                availableVideoUids = availableUids,
                                onCreateFolder = { name ->
                                    scope.launch {
                                        app.database.reviewDao().insertFolder(
                                            ReviewFolderEntity(name = name, createdAtMs = System.currentTimeMillis())
                                        )
                                    }
                                },
                                onRenameFolder = { id, newName ->
                                    scope.launch { app.database.reviewDao().renameFolder(id, newName) }
                                },
                                onDeleteFolder = { folder ->
                                    scope.launch { app.database.reviewDao().deleteFolder(folder) }
                                },
                                onMoveReview = { reviewId, folderId ->
                                    scope.launch { app.database.reviewDao().moveReviewToFolder(reviewId, folderId) }
                                },
                                onUpdateReview = { rev ->
                                    scope.launch { app.database.reviewDao().upsertReview(rev) }
                                },
                                onDeleteReview = { rev ->
                                    scope.launch { app.database.reviewDao().deleteReview(rev) }
                                }
                            )

                            MainTab.HISTORY -> HistoryScreen(
                                sessions = allSessions,
                                availableVideoUids = availableUids,
                                onOpenVideoInfo = { uid -> activeInfoVideoUid = uid }
                            )

                            MainTab.SETTINGS -> SettingsScreen(
                                prefs = prefs,
                                onUpdatePrefs = { transform ->
                                    scope.launch { app.preferences.update(transform) }
                                },
                                onResetBrightness = {
                                    scope.launch {
                                        app.preferences.resetBrightnessPreferences()
                                        Toast.makeText(app, "Brightness preferences reset", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onRescanLibrary = { triggerScan() },
                                onAddSafFolder = { addSafFolderLauncher.launch(null) },
                                onExportReviewsBackup = { exportReviewsLauncher.launch("lumaplayer_reviews_backup.json") },
                                onOpenPlayerLab = { showPlayerLab = true }
                            )
                        }
                    }
                }
            }
        }

        // Automatic or Manual Video Review Dialog
        pendingReviewVideo?.let { targetVideo ->
            ReviewPromptDialog(
                videoUid = targetVideo.uid,
                videoTitle = targetVideo.displayName,
                dateWatchedMs = System.currentTimeMillis(),
                folders = reviewFolders,
                onCreateFolder = { name ->
                    scope.launch {
                        app.database.reviewDao().insertFolder(
                            ReviewFolderEntity(name = name, createdAtMs = System.currentTimeMillis())
                        )
                    }
                },
                onSubmit = { review ->
                    scope.launch {
                        app.database.reviewDao().upsertReview(review)
                        app.database.videoDao().setReviewDismissed(targetVideo.uid, false)
                    }
                    pendingReviewVideo = null
                },
                onDismiss = {
                    scope.launch { app.database.videoDao().setReviewDismissed(targetVideo.uid, true) }
                    pendingReviewVideo = null
                }
            )
        }
    }
}
