package com.lumaplayer.app

import com.lumaplayer.app.domain.ReviewThresholdConfig
import com.lumaplayer.app.domain.ReviewTriggerEngine
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReviewTriggerEngineTest {

    private val defaultConfig = ReviewThresholdConfig(
        autoPromptEnabled = true,
        longVideoRemainingMinutes = 10,
        mediumVideoRemainingMinutes = 2,
        shortVideoMinPercent = 90
    )

    @Test
    fun longVideo_triggersInFinalTenMinutes() {
        val durationMs = 120 * 60_000L // 2 hours
        assertTrue(
            ReviewTriggerEngine.shouldPromptForReview(
                durationMs = durationMs,
                exitPositionMs = 112 * 60_000L, // 8 min left
                completedNormally = false,
                alreadyReviewed = false,
                previouslyDismissed = false,
                config = defaultConfig
            )
        )
        assertFalse(
            ReviewTriggerEngine.shouldPromptForReview(
                durationMs = durationMs,
                exitPositionMs = 100 * 60_000L, // 20 min left
                completedNormally = false,
                alreadyReviewed = false,
                previouslyDismissed = false,
                config = defaultConfig
            )
        )
    }

    @Test
    fun mediumVideo_triggersInFinalTwoMinutes() {
        val durationMs = 30 * 60_000L // 30 minutes
        assertTrue(
            ReviewTriggerEngine.shouldPromptForReview(
                durationMs = durationMs,
                exitPositionMs = 28 * 60_000L + 30_000L, // 1.5 min left
                completedNormally = false,
                alreadyReviewed = false,
                previouslyDismissed = false,
                config = defaultConfig
            )
        )
        assertFalse(
            ReviewTriggerEngine.shouldPromptForReview(
                durationMs = durationMs,
                exitPositionMs = 25 * 60_000L, // 5 min left
                completedNormally = false,
                alreadyReviewed = false,
                previouslyDismissed = false,
                config = defaultConfig
            )
        )
    }

    @Test
    fun earlyExitOrDismissed_neverPrompts() {
        val durationMs = 60 * 60_000L
        assertFalse(
            ReviewTriggerEngine.shouldPromptForReview(
                durationMs = durationMs,
                exitPositionMs = 5 * 60_000L,
                completedNormally = false,
                alreadyReviewed = false,
                previouslyDismissed = false,
                config = defaultConfig
            )
        )
        assertFalse(
            ReviewTriggerEngine.shouldPromptForReview(
                durationMs = durationMs,
                exitPositionMs = durationMs,
                completedNormally = true,
                alreadyReviewed = false,
                previouslyDismissed = true,
                config = defaultConfig
            )
        )
        assertFalse(
            ReviewTriggerEngine.shouldPromptForReview(
                durationMs = durationMs,
                exitPositionMs = durationMs,
                completedNormally = true,
                alreadyReviewed = true,
                previouslyDismissed = false,
                config = defaultConfig
            )
        )
    }
}
