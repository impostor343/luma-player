package com.lumaplayer.app

import com.lumaplayer.app.data.prefs.BrightnessBehavior
import com.lumaplayer.app.data.prefs.HdrBrightnessBehavior
import com.lumaplayer.app.domain.EyeComfortController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EyeComfortControllerTest {

    @Test
    fun maxBrightness_compensatesSubtitleAndHudLuminanceSoTheyLookNormal() {
        val state = EyeComfortController.computeRenderState(
            requestedBrightness = 1.0f,
            isHdrVideo = false,
            sdrBehavior = BrightnessBehavior.VIDEO_SURFACE_ONLY,
            hdrBehavior = HdrBrightnessBehavior.PRESERVE_HDR_HEADROOM,
            subtitleCompensationEnabled = true
        )
        assertEquals(0f, state.videoDimScrimAlpha, 0.001f)
        // Subtitles and HUD must be smoothly attenuated below 0.80 at max brightness
        assertTrue("Subtitle luminance should be compensated at max brightness", state.subtitleLuminanceFactor <= 0.72f)
        assertTrue("HUD luminance should be compensated at max brightness", state.hudLuminanceFactor <= 0.80f)
        assertTrue("Subtitle backing boost should activate at high brightness", state.subtitleBackingBoost > 0f)
    }

    @Test
    fun hdrPlayback_preservesHdrHeadroomAndKeepsSubtitlesCalm() {
        val state = EyeComfortController.computeRenderState(
            requestedBrightness = 0.85f,
            isHdrVideo = true,
            sdrBehavior = BrightnessBehavior.VIDEO_SURFACE_ONLY,
            hdrBehavior = HdrBrightnessBehavior.PRESERVE_HDR_HEADROOM,
            subtitleCompensationEnabled = true
        )
        assertNull("HDR headroom mode should not override window brightness", state.windowBrightnessOverride)
        assertEquals(0f, state.videoDimScrimAlpha, 0.001f)
        assertTrue("HDR subtitles must stay eye-safe", state.subtitleLuminanceFactor <= 0.75f)
    }

    @Test
    fun argbLuminanceAttenuation_preservesAlphaAndDimsRgb() {
        val pureWhite = 0xFFFFFFFF.toInt()
        val compensated = EyeComfortController.applyLuminanceToArgb(pureWhite, 0.70f)
        val alpha = (compensated ushr 24) and 0xFF
        val red = (compensated ushr 16) and 0xFF
        assertEquals(255, alpha)
        assertTrue("Red channel should be dimmed to ~178, got $red", red in 175..182)
    }
}
