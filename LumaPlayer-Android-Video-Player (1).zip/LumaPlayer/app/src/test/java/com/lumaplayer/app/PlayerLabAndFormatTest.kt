package com.lumaplayer.app

import com.lumaplayer.app.data.prefs.PlaybackProfile
import com.lumaplayer.app.data.prefs.PlayerLabConfig
import com.lumaplayer.app.domain.FormatUtils
import com.lumaplayer.app.domain.PlayerLabValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerLabAndFormatTest {

    @Test
    fun defaultPlayerLabConfig_isValid() {
        val result = PlayerLabValidator.validate(PlayerLabConfig())
        assertTrue(result.isValid)
        assertTrue(result.errors.isEmpty())
    }

    @Test
    fun invalidBufferOrderAndConflictingHdrModes_areRejected() {
        val bad = PlayerLabConfig(
            minBufferMs = 40_000,
            maxBufferMs = 20_000, // invalid: max < min
            hdrStrictMode = true,
            hdrCompatibilityToneMap = true // invalid: both enabled
        )
        val result = PlayerLabValidator.validate(bad)
        assertFalse(result.isValid)
        assertTrue(result.errors.size >= 2)
    }

    @Test
    fun profilePreset_appliesHighBitrateHdrSafely() {
        val updated = PlayerLabValidator.applyProfilePreset(PlayerLabConfig(), PlaybackProfile.HIGH_BITRATE_HDR)
        val validation = PlayerLabValidator.validate(updated, PlayerLabConfig())
        assertTrue(validation.isValid)
        assertTrue(validation.requiresPlaybackRestart)
    }

    @Test
    fun formatUtils_formatsResolutionAndTimestampsCorrectly() {
        assertEquals("4K", FormatUtils.formatResolutionBadge(3840, 2160))
        assertEquals("1440p", FormatUtils.formatResolutionBadge(2560, 1440))
        assertEquals("1080p", FormatUtils.formatResolutionBadge(1920, 1080))
        assertEquals("720p", FormatUtils.formatResolutionBadge(1280, 720))
        assertEquals("01:42:15", FormatUtils.formatTimelineTimestamp((1 * 3600 + 42 * 60 + 15) * 1000L))
    }
}
