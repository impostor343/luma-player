package com.lumaplayer.app.ui.reviews

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lumaplayer.app.data.db.ReviewFolderEntity
import com.lumaplayer.app.data.db.VideoReviewEntity
import com.lumaplayer.app.domain.FormatUtils

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReviewPromptDialog(
    videoUid: String,
    videoTitle: String,
    dateWatchedMs: Long,
    folders: List<ReviewFolderEntity>,
    existingReview: VideoReviewEntity? = null,
    onCreateFolder: (String) -> Unit,
    onSubmit: (VideoReviewEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var rating by remember { mutableIntStateOf(existingReview?.rating ?: 4) }
    var writtenReview by remember { mutableStateOf(existingReview?.writtenReview ?: "") }
    var notes by remember { mutableStateOf(existingReview?.notes ?: "") }
    var tags by remember { mutableStateOf(existingReview?.tags ?: "") }
    var selectedFolderId by remember { mutableStateOf(existingReview?.folderId) }
    var showNewFolderField by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = if (existingReview == null) "Review Video" else "Edit Review",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = videoTitle.substringBeforeLast('.'),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Watched on ${FormatUtils.formatDateOnly(dateWatchedMs)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // 1 to 5 star rating
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (star in 1..5) {
                        IconButton(onClick = { rating = star }) {
                            Icon(
                                imageVector = if (star <= rating) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                contentDescription = "$star stars",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = writtenReview,
                    onValueChange = { writtenReview = it },
                    label = { Text("Written review (optional)") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Personal notes (optional)") },
                    minLines = 1,
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    label = { Text("Tags (comma-separated, optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Review Folder",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Medium
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterChip(
                        selected = selectedFolderId == null,
                        onClick = { selectedFolderId = null },
                        label = { Text("Unfiled") }
                    )
                    folders.forEach { folder ->
                        FilterChip(
                            selected = selectedFolderId == folder.folderId,
                            onClick = { selectedFolderId = folder.folderId },
                            label = { Text(folder.name) }
                        )
                    }
                    FilterChip(
                        selected = showNewFolderField,
                        onClick = { showNewFolderField = !showNewFolderField },
                        label = { Text("New Folder") },
                        leadingIcon = { Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                if (showNewFolderField) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newFolderName,
                            onValueChange = { newFolderName = it },
                            label = { Text("Folder name") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val trimmed = newFolderName.trim()
                                if (trimmed.isNotEmpty()) {
                                    onCreateFolder(trimmed)
                                    newFolderName = ""
                                    showNewFolderField = false
                                }
                            }
                        ) {
                            Text("Add")
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val now = System.currentTimeMillis()
                    onSubmit(
                        VideoReviewEntity(
                            reviewId = existingReview?.reviewId ?: 0L,
                            videoUid = videoUid,
                            videoTitleSnapshot = videoTitle,
                            rating = rating.coerceIn(1, 5),
                            writtenReview = writtenReview.trim(),
                            notes = notes.trim(),
                            tags = tags.trim(),
                            folderId = selectedFolderId,
                            dateWatchedMs = dateWatchedMs,
                            dateReviewedMs = now
                        )
                    )
                }
            ) {
                Text("Save Review")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Later")
            }
        }
    )
}
