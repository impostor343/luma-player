package com.lumaplayer.app.domain

import androidx.compose.ui.graphics.Color
import com.lumaplayer.app.data.prefs.BrightnessBehavior
import com.lumaplayer.app.data.prefs.HdrBrightnessBehavior

/**
 * Computes video-surface luminance adjustments while keeping player controls and subtitles
 * comfortable to look at — even at maximum video brightness.
 */
data class EyeComfortRenderState(
    /** Black scrim alpha over the video surface ONLY (0f = full brightness, up to 0.72f = dimmed). */
    val videoDimScrimAlpha: Float,
    /** Gentle window brightness override (null = leave system/default window brightness untouched). */
    val windowBrightnessOverride: Float?,
    /** Luminance multiplier applied to player HUD text/icons so they never look glaringly bright. */
    val hudLuminanceFactor: Float,
    /** Luminance multiplier applied to subtitle text so subtitles stay natural at max brightness. */
    val subtitleLuminanceFactor: Float,
    /** Extra soft dark backing alpha behind subtitles when brightness is high. */
    val subtitleBackingBoost: Float
)

object EyeComfortController {

    /**
     * @param requestedBrightness User brightness slider/gesture value in [0.05f, 1.0f]
     * @param isHdrVideo True when active source is HDR10 / HDR10+ / HLG / Dolby Vision
     * @param sdrBehavior User's configured SDR video brightness behavior
     * @param hdrBehavior User's configured HDR brightness behavior (kept separate from SDR)
     * @param subtitleCompensationEnabled Keeps subtitles at normal, eye-safe brightness at max brightness
     */
    fun computeRenderState(
        requestedBrightness: Float,
        isHdrVideo: Boolean,
        sdrBehavior: BrightnessBehavior,
        hdrBehavior: HdrBrightnessBehavior,
        subtitleCompensationEnabled: Boolean
    ): EyeComfortRenderState {
        val level = requestedBrightness.coerceIn(0.05f, 1.0f)

        // 1. Determine video-surface dim scrim and optional window brightness
        var videoDimAlpha = 0f
        var windowOverride: Float? = null

        if (isHdrVideo) {
            when (hdrBehavior) {
                HdrBrightnessBehavior.PRESERVE_HDR_HEADROOM -> {
                    // Never force system brightness down or crush HDR highlights; only dim below 0.65 if requested
                    videoDimAlpha = if (level < 0.65f) ((0.65f - level) / 0.65f) * 0.55f else 0f
                    windowOverride = null
                }
                HdrBrightnessBehavior.ALLOW_DIMMING_ONLY -> {
                    videoDimAlpha = ((1f - level) * 0.65f).coerceIn(0f, 0.65f)
                    windowOverride = null
                }
                HdrBrightnessBehavior.LOCK_HDR_DEFAULT -> {
                    videoDimAlpha = 0f
                    windowOverride = null
                }
            }
        } else {
            when (sdrBehavior) {
                BrightnessBehavior.VIDEO_SURFACE_ONLY -> {
                    // Affect only the video surface via dimming scrim below 0.85, leaving phone display brightness normal
                    videoDimAlpha = if (level < 0.85f) {
                        ((0.85f - level) / 0.85f) * 0.72f
                    } else {
                        0f
                    }
                    // Above 0.85, apply only a gentle capped window boost (max 0.82) so UI isn't blinded
                    windowOverride = if (level > 0.85f) {
                        0.68f + ((level - 0.85f) / 0.15f) * 0.14f
                    } else {
                        null
                    }
                }
                BrightnessBehavior.HYBRID_CAPPED -> {
                    videoDimAlpha = if (level < 0.5f) ((0.5f - level) / 0.5f) * 0.45f else 0f
                    windowOverride = (0.25f + level * 0.65f).coerceIn(0.25f, 0.90f)
                }
                BrightnessBehavior.SYSTEM_DEFAULT -> {
                    videoDimAlpha = 0f
                    windowOverride = null
                }
            }
        }

        // 2. Eye-comfort compensation for HUD controls and Subtitles at high/maximum brightness.
        // As video brightness approaches 1.0 (or during HDR playback), scale down HUD and subtitle
        // white luminance so neither controls nor subtitles ever look blown-out or blinding.
        val effectiveHighBrightness = when {
            isHdrVideo -> level.coerceAtLeast(0.75f)
            else -> level
        }
        val hudFactor = if (effectiveHighBrightness > 0.65f) {
            val t = ((effectiveHighBrightness - 0.65f) / 0.35f).coerceIn(0f, 1f)
            1.0f - (t * 0.24f) // smoothly settles to 0.76 at max brightness
        } else {
            0.94f
        }

        val subtitleFactor = if (subtitleCompensationEnabled) {
            when {
                isHdrVideo -> 0.70f // HDR panels push peak nits very high; keep subtitles at calm ~70% SDR white
                effectiveHighBrightness > 0.55f -> {
                    val t = ((effectiveHighBrightness - 0.55f) / 0.45f).coerceIn(0f, 1f)
                    0.92f - (t * 0.24f) // smoothly settles to 0.68 at max brightness — looks completely normal!
                }
                else -> 0.92f
            }
        } else {
            0.95f
        }

        val subtitleBackingBoost = if (subtitleCompensationEnabled && effectiveHighBrightness > 0.7f) {
            0.12f
        } else {
            0f
        }

        return EyeComfortRenderState(
            videoDimScrimAlpha = videoDimAlpha.coerceIn(0f, 0.72f),
            windowBrightnessOverride = windowOverride,
            hudLuminanceFactor = hudFactor.coerceIn(0.68f, 0.96f),
            subtitleLuminanceFactor = subtitleFactor.coerceIn(0.65f, 0.95f),
            subtitleBackingBoost = subtitleBackingBoost
        )
    }

    /**
     * Scales RGB channels of a Compose Color by [luminanceFactor] while preserving alpha and hue.
     */
    fun applyLuminanceFactor(baseColor: Color, luminanceFactor: Float): Color {
        val f = luminanceFactor.coerceIn(0.5f, 1.0f)
        return Color(
            red = (baseColor.red * f).coerceIn(0f, 1f),
            green = (baseColor.green * f).coerceIn(0f, 1f),
            blue = (baseColor.blue * f).coerceIn(0f, 1f),
            alpha = baseColor.alpha
        )
    }

    /**
     * Returns an ARGB Int suitable for Media3 CaptionStyleCompat foreground color,
     * dimmed smoothly when video brightness is high so subtitles never glare.
     */
    fun applyLuminanceToArgb(baseArgb: Int, luminanceFactor: Float): Int {
        val f = luminanceFactor.coerceIn(0.5f, 1.0f)
        val a = (baseArgb ushr 24) and 0xFF
        val r = (((baseArgb ushr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((baseArgb ushr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((baseArgb and 0xFF) * f).toInt().coerceIn(0, 255)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }
}
