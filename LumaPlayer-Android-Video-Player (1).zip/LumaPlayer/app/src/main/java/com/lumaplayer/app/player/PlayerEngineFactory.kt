package com.lumaplayer.app.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.lumaplayer.app.data.prefs.AppPreferences
import com.lumaplayer.app.data.prefs.DecoderPreference
import com.lumaplayer.app.domain.PlayerLabValidator

data class TrackOption(
    val id: String,
    val label: String,
    val language: String?,
    val groupIndex: Int,
    val trackIndex: Int,
    val isSelected: Boolean,
    val channelCount: Int = 0,
    val codec: String? = null
)

object PlayerEngineFactory {

    @OptIn(UnstableApi::class)
    fun createExoPlayer(
        context: Context,
        prefs: AppPreferences
    ): ExoPlayer {
        val lab = prefs.playerLab
        val validation = PlayerLabValidator.validate(lab)
        val safeLab = if (validation.isValid) lab else com.lumaplayer.app.data.prefs.PlayerLabConfig()

        val decoderPref = runCatching { DecoderPreference.valueOf(safeLab.decoderPreference) }
            .getOrDefault(prefs.decoderPreference)

        val renderersFactory = DefaultRenderersFactory(context).apply {
            when (decoderPref) {
                DecoderPreference.HARDWARE_PREFERRED -> {
                    setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
                    setEnableDecoderFallback(true)
                }
                DecoderPreference.HARDWARE_WITH_FALLBACK -> {
                    setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                    setEnableDecoderFallback(true)
                }
                DecoderPreference.SOFTWARE_WHEN_AVAILABLE -> {
                    setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                    setEnableDecoderFallback(true)
                }
            }
            if (safeLab.enableAsyncMediaCodecQueueing) {
                forceEnableMediaCodecAsynchronousQueueing()
            } else {
                forceDisableMediaCodecAsynchronousQueueing()
            }
        }

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                safeLab.minBufferMs,
                safeLab.maxBufferMs,
                safeLab.bufferForPlaybackMs,
                safeLab.bufferForPlaybackAfterRebufferMs
            )
            .build()

        val trackSelector = DefaultTrackSelector(context).apply {
            val builder = buildUponParameters()
                .setTunnelingEnabled(safeLab.enableAudioTunneling)
            if (prefs.preferredAudioLanguage != "System Default") {
                builder.setPreferredAudioLanguage(prefs.preferredAudioLanguage)
            }
            if (prefs.preferredSubtitleLanguage != "System Default") {
                builder.setPreferredTextLanguage(prefs.preferredSubtitleLanguage)
            }
            setParameters(builder)
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        // Screen-on is handled via Window FLAG_KEEP_SCREEN_ON & PlayerView.keepScreenOn
        // (avoids requiring android.permission.WAKE_LOCK which throws SecurityException if missing).
        return ExoPlayer.Builder(context, renderersFactory)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    fun extractAudioTracks(tracks: Tracks): List<TrackOption> {
        val result = mutableListOf<TrackOption>()
        tracks.groups.forEachIndexed { gIdx, group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (tIdx in 0 until group.length) {
                    val format = group.getTrackFormat(tIdx)
                    val lang = format.language ?: "Unknown"
                    val channels = format.channelCount.takeIf { it > 0 } ?: 2
                    val chLabel = when (channels) {
                        1 -> "Mono"
                        2 -> "Stereo"
                        6 -> "5.1"
                        8 -> "7.1"
                        else -> "${channels}ch"
                    }
                    val codec = format.sampleMimeType?.substringAfter('/')?.uppercase() ?: "AUDIO"
                    val label = format.label?.takeIf { it.isNotBlank() }
                        ?: "${lang.uppercase()} • $chLabel ($codec)"
                    result.add(
                        TrackOption(
                            id = "a_${gIdx}_$tIdx",
                            label = label,
                            language = format.language,
                            groupIndex = gIdx,
                            trackIndex = tIdx,
                            isSelected = group.isTrackSelected(tIdx),
                            channelCount = channels,
                            codec = codec
                        )
                    )
                }
            }
        }
        return result
    }

    fun extractSubtitleTracks(tracks: Tracks): List<TrackOption> {
        val result = mutableListOf<TrackOption>()
        tracks.groups.forEachIndexed { gIdx, group ->
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (tIdx in 0 until group.length) {
                    val format = group.getTrackFormat(tIdx)
                    val lang = format.language ?: "Unknown"
                    val codec = format.sampleMimeType?.substringAfter('/')?.uppercase() ?: "SUB"
                    val label = format.label?.takeIf { it.isNotBlank() }
                        ?: "${lang.uppercase()} ($codec)"
                    result.add(
                        TrackOption(
                            id = "t_${gIdx}_$tIdx",
                            label = label,
                            language = format.language,
                            groupIndex = gIdx,
                            trackIndex = tIdx,
                            isSelected = group.isTrackSelected(tIdx),
                            codec = codec
                        )
                    )
                }
            }
        }
        return result
    }

    fun selectTrack(player: ExoPlayer, trackType: Int, option: TrackOption?) {
        val paramsBuilder = player.trackSelectionParameters.buildUpon()
        if (option == null) {
            paramsBuilder.setTrackTypeDisabled(trackType, true)
        } else {
            val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return
            paramsBuilder
                .setTrackTypeDisabled(trackType, false)
                .setOverrideForType(
                    TrackSelectionOverride(group.mediaTrackGroup, listOf(option.trackIndex))
                )
        }
        player.trackSelectionParameters = paramsBuilder.build()
    }
}
