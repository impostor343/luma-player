package com.lumaplayer.app.domain

import com.lumaplayer.app.data.prefs.DecoderPreference
import com.lumaplayer.app.data.prefs.PlaybackProfile
import com.lumaplayer.app.data.prefs.PlayerLabConfig
import com.lumaplayer.app.data.prefs.PlayerLabMode
import com.lumaplayer.app.data.prefs.VideoDisplayMode

data class PlayerLabValidationResult(
    val isValid: Boolean,
    val errors: List<String>,
    val requiresPlaybackRestart: Boolean
)

object PlayerLabValidator {

    fun validate(config: PlayerLabConfig, previous: PlayerLabConfig? = null): PlayerLabValidationResult {
        val errors = mutableListOf<String>()

        if (config.minBufferMs < 2_000 || config.minBufferMs > 120_000) {
            errors.add("Minimum buffer must be between 2,000 ms and 120,000 ms.")
        }
        if (config.maxBufferMs < config.minBufferMs || config.maxBufferMs > 240_000) {
            errors.add("Maximum buffer must be >= Minimum buffer and at most 240,000 ms.")
        }
        if (config.bufferForPlaybackMs < 250 || config.bufferForPlaybackMs > config.minBufferMs) {
            errors.add("Buffer for playback must be between 250 ms and Minimum buffer (${config.minBufferMs} ms).")
        }
        if (config.bufferForPlaybackAfterRebufferMs < 500 || config.bufferForPlaybackAfterRebufferMs > config.minBufferMs) {
            errors.add("Rebuffer threshold must be between 500 ms and Minimum buffer (${config.minBufferMs} ms).")
        }
        if (config.doubleTapSeekSec !in 3..60) {
            errors.add("Double-tap seek interval must be between 3 and 60 seconds.")
        }
        if (config.longPressSpeed < 1.25f || config.longPressSpeed > 4.0f) {
            errors.add("Long-press speed must be between 1.25x and 4.0x.")
        }
        if (runCatching { PlayerLabMode.valueOf(config.mode) }.isFailure) {
            errors.add("Unknown Player Lab mode: ${config.mode}.")
        }
        if (runCatching { PlaybackProfile.valueOf(config.profile) }.isFailure) {
            errors.add("Unknown playback profile: ${config.profile}.")
        }
        if (runCatching { DecoderPreference.valueOf(config.decoderPreference) }.isFailure) {
            errors.add("Unknown decoder preference: ${config.decoderPreference}.")
        }
        if (runCatching { VideoDisplayMode.valueOf(config.defaultDisplayMode) }.isFailure) {
            errors.add("Unknown display mode: ${config.defaultDisplayMode}.")
        }
        if (config.hdrStrictMode && config.hdrCompatibilityToneMap) {
            errors.add("HDR Strict Mode and HDR Compatibility Tone-Mapping cannot both be active at the same time.")
        }

        val requiresRestart = previous != null && (
            previous.minBufferMs != config.minBufferMs ||
                previous.maxBufferMs != config.maxBufferMs ||
                previous.bufferForPlaybackMs != config.bufferForPlaybackMs ||
                previous.bufferForPlaybackAfterRebufferMs != config.bufferForPlaybackAfterRebufferMs ||
                previous.decoderPreference != config.decoderPreference ||
                previous.enableAudioTunneling != config.enableAudioTunneling ||
                previous.enableAsyncMediaCodecQueueing != config.enableAsyncMediaCodecQueueing
            )

        return PlayerLabValidationResult(
            isValid = errors.isEmpty(),
            errors = errors,
            requiresPlaybackRestart = requiresRestart
        )
    }

    fun applyProfilePreset(current: PlayerLabConfig, profile: PlaybackProfile): PlayerLabConfig {
        return when (profile) {
            PlaybackProfile.BALANCED -> current.copy(
                profile = profile.name,
                decoderPreference = DecoderPreference.HARDWARE_WITH_FALLBACK.name,
                minBufferMs = 15_000,
                maxBufferMs = 50_000,
                bufferForPlaybackMs = 1_500,
                bufferForPlaybackAfterRebufferMs = 3_000,
                enableAsyncMediaCodecQueueing = true
            )
            PlaybackProfile.HIGH_BITRATE_HDR -> current.copy(
                profile = profile.name,
                decoderPreference = DecoderPreference.HARDWARE_PREFERRED.name,
                minBufferMs = 30_000,
                maxBufferMs = 90_000,
                bufferForPlaybackMs = 2_500,
                bufferForPlaybackAfterRebufferMs = 5_000,
                hdrStrictMode = true,
                hdrCompatibilityToneMap = false,
                enableAsyncMediaCodecQueueing = true
            )
            PlaybackProfile.LOW_LATENCY_SEEK -> current.copy(
                profile = profile.name,
                decoderPreference = DecoderPreference.HARDWARE_WITH_FALLBACK.name,
                minBufferMs = 6_000,
                maxBufferMs = 20_000,
                bufferForPlaybackMs = 500,
                bufferForPlaybackAfterRebufferMs = 1_000,
                enableAsyncMediaCodecQueueing = true
            )
            PlaybackProfile.BATTERY_SAVER -> current.copy(
                profile = profile.name,
                decoderPreference = DecoderPreference.HARDWARE_PREFERRED.name,
                minBufferMs = 12_000,
                maxBufferMs = 35_000,
                bufferForPlaybackMs = 2_000,
                bufferForPlaybackAfterRebufferMs = 4_000,
                enableAudioTunneling = false,
                enableAsyncMediaCodecQueueing = false
            )
        }
    }
}
