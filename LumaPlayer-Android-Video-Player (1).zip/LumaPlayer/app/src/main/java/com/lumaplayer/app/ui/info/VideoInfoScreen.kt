package com.lumaplayer.app.ui.info

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RateReview
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lumaplayer.app.data.db.PlaybackEventEntity
import com.lumaplayer.app.data.db.PlaybackSessionEntity
import com.lumaplayer.app.data.db.VideoEntity
import com.lumaplayer.app.domain.FormatUtils
import com.lumaplayer.app.domain.HdrFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoInfoScreen(
    video: VideoEntity?,
    sessions: List<PlaybackSessionEntity>,
    eventsBySession: Map<Long, List<PlaybackEventEntity>>,
    onBack: () -> Unit,
    onPlay: (VideoEntity) -> Unit,
    onToggleFavourite: (VideoEntity) -> Unit,
    onWriteReview: (VideoEntity) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Video Information & Logbook", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (video != null) {
                        IconButton(onClick = { onToggleFavourite(video) }) {
                            Icon(
                                imageVector = if (video.isFavourite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                contentDescription = "Toggle favourite",
                                tint = if (video.isFavourite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        if (video == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Video record not found.", style = MaterialTheme.typography.titleMedium)
            }
            return@Scaffold
        }

        val hdr = HdrFormat.fromStored(video.hdrType)
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = video.displayName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                if (!video.isAvailable) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Original video file is currently unavailable or deleted. Logbook and reviews are preserved.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onPlay(video) },
                        enabled = video.isAvailable
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.padding(2.dp))
                        Text(if (video.lastPositionMs > 5000) "Resume" else "Play")
                    }
                    OutlinedButton(onClick = { onWriteReview(video) }) {
                        Icon(Icons.Rounded.RateReview, contentDescription = null)
                        Spacer(modifier = Modifier.padding(2.dp))
                        Text("Review")
                    }
                }
            }

            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Technical Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(10.dp))
                        InfoRow("File Name", video.displayName)
                        InfoRow("File Size", FormatUtils.formatFileSize(video.sizeBytes))
                        InfoRow("Resolution", "${video.width} × ${video.height} (${FormatUtils.formatResolutionBadge(video.width, video.height)})")
                        InfoRow("Frame Rate", if (video.frameRate > 0f) String.format("%.2f fps", video.frameRate) else "Detected at playback")
                        InfoRow("Duration", FormatUtils.formatTimelineTimestamp(video.durationMs))
                        InfoRow("Aspect Ratio", FormatUtils.formatAspectRatio(video.width, video.height))
                        InfoRow("Video Codec", video.videoCodec.ifBlank { "Detected at playback" })
                        InfoRow("Bit Depth", "${video.bitDepth}-bit")
                        InfoRow("HDR / SDR Format", hdr.badgeLabel)
                        InfoRow("Color Information", video.colorInfoText.ifBlank { "Standard" })
                        InfoRow("Audio Codec", video.audioCodec.ifBlank { "Detected at playback" })
                        InfoRow("Location", video.folderPath)
                        InfoRow("Last Played", if (video.lastPlayedAtMs > 0) FormatUtils.formatClockDateTime(video.lastPlayedAtMs) else "Never")
                        InfoRow("Last Position", FormatUtils.formatTimelineTimestamp(video.lastPositionMs))
                    }
                }
            }

            item {
                Text(
                    text = "Playback Logbook (${sessions.size} session${if (sessions.size == 1) "" else "s"})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (sessions.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No playback sessions recorded for this video yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                // Show Session 1, Session 2... chronologically or newest first with clear session numbers
                val chronological = sessions.sortedBy { it.openedAtClockMs }
                itemsIndexed(chronological.reversed(), key = { _, s -> s.sessionId }) { revIdx, session ->
                    val sessionNum = chronological.size - revIdx
                    val events = eventsBySession[session.sessionId].orEmpty()
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Session $sessionNum",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (session.completed) {
                                    Text(
                                        text = "Completed",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            InfoRow("Opened (Clock)", FormatUtils.formatClockDateTime(session.openedAtClockMs))
                            InfoRow("Started At (Video)", FormatUtils.formatTimelineTimestamp(session.startedAtPositionMs))
                            events.filter { it.eventType == "PAUSED" || it.eventType == "RESUMED" || it.eventType == "COMPLETED" }
                                .forEach { ev ->
                                    val label = when (ev.eventType) {
                                        "PAUSED" -> "Paused (${FormatUtils.formatClockTimeOnly(ev.clockTimestampMs)})"
                                        "RESUMED" -> "Resumed (${FormatUtils.formatClockTimeOnly(ev.clockTimestampMs)})"
                                        "COMPLETED" -> "Completed (${FormatUtils.formatClockTimeOnly(ev.clockTimestampMs)})"
                                        else -> ev.eventType
                                    }
                                    InfoRow(label, FormatUtils.formatTimelineTimestamp(ev.videoPositionMs))
                                }
                            if (session.exitedAtClockMs > 0L) {
                                InfoRow("Exited (Clock)", FormatUtils.formatClockDateTime(session.exitedAtClockMs))
                                InfoRow("Exit Position (Video)", FormatUtils.formatTimelineTimestamp(session.exitPositionMs))
                            }
                            InfoRow("Active Viewing Time", FormatUtils.formatDuration(session.totalViewingTimeMs))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(0.45f)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(0.55f)
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
    }
}
