package com.lumaplayer.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        VideoEntity::class,
        PlaybackSessionEntity::class,
        PlaybackEventEntity::class,
        ReviewFolderEntity::class,
        VideoReviewEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class LumaDatabase : RoomDatabase() {
    abstract fun videoDao(): VideoDao
    abstract fun playbackLogDao(): PlaybackLogDao
    abstract fun reviewDao(): ReviewDao

    companion object {
        @Volatile
        private var INSTANCE: LumaDatabase? = null

        fun getInstance(context: Context): LumaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LumaDatabase::class.java,
                    "lumaplayer_database.db"
                )
                    // Never silently wipe user data on schema updates; add explicit Migrations here.
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
