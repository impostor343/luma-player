package com.lumaplayer.app.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.util.Rational
import android.util.TypedValue
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.lumaplayer.app.LumaApplication
import com.lumaplayer.app.data.db.VideoEntity
import com.lumaplayer.app.data.prefs.AppPreferences
import com.lumaplayer.app.data.prefs.OrientationMode
import com.lumaplayer.app.data.prefs.VideoDisplayMode
import com.lumaplayer.app.domain.EyeComfortController
import com.lumaplayer.app.domain.FormatUtils
import com.lumaplayer.app.domain.HdrDetector
import com.lumaplayer.app.domain.HdrFormat
import com.lumaplayer.app.domain.HdrPlaybackReport
import com.lumaplayer.app.player.PlaybackLogbookRecorder
import com.lumaplayer.app.player.PlayerEngineFactory
import com.lumaplayer.app.player.TrackOption
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    video: VideoEntity,
    playlist: List<VideoEntity>,
    prefs: AppPreferences,
    isInPipMode: Boolean,
    onSaveBrightness: (Float) -> Unit,
    onOpenVideoInfo: (VideoEntity) -> Unit,
    onSwitchVideo: (VideoEntity) -> Unit,
    onExitPlayer: (exitPositionMs: Long, durationMs: Long, completed: Boolean) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val app = context.applicationContext as LumaApplication
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }

    val exoPlayer = remember(video.uid) {
        PlayerEngineFactory.createExoPlayer(context, prefs)
    }

    val logbookRecorder = remember(video.uid) {
        PlaybackLogbookRecorder(
            logDao = app.database.playbackLogDao(),
            videoDao = app.database.videoDao(),
            scope = coroutineScope
        )
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(video.durationMs.coerceAtLeast(0L)) }
    var completedNormally by remember { mutableStateOf(false) }
    var playbackError by remember { mutableStateOf<String?>(null) }

    var controlsVisible by remember { mutableStateOf(true) }
    var lastInteractionMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var isScreenLocked by remember { mutableStateOf(false) }
    var isRotationLocked by remember { mutableStateOf(false) }

    var displayMode by remember { mutableStateOf(prefs.defaultDisplayMode) }
    var zoomScale by remember { mutableFloatStateOf(1.0f) }

    var normalPlaybackSpeed by remember { mutableFloatStateOf(prefs.defaultPlaybackSpeed) }
    var isLongPressSpeedActive by remember { mutableStateOf(false) }

    var videoBrightness by remember {
        mutableFloatStateOf(if (prefs.rememberBrightness) prefs.savedVideoBrightness else 0.75f)
    }
    var gestureHudText by remember { mutableStateOf<String?>(null) }
    var audioTracks by remember { mutableStateOf<List<TrackOption>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<TrackOption>>(emptyList()) }
    var detectedHdrFormat by remember { mutableStateOf(HdrFormat.fromStored(video.hdrType)) }
    var hdrReport by remember {
        mutableStateOf(
            HdrDetector.evaluateOutputStatus(
                context = context,
                sourceFormat = detectedHdrFormat,
                hdrStrictMode = prefs.hdrStrictMode,
                hdrCompatibilityMode = prefs.hdrCompatibilityMode
            )
        )
    }

    // Dialog / Menu states
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var showDisplayModeDialog by remember { mutableStateOf(false) }
    var showHdrInfoDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }

    // A-B Repeat & Sleep Timer
    var repeatPointAMs by remember { mutableStateOf<Long?>(null) }
    var repeatPointBMs by remember { mutableStateOf<Long?>(null) }
    var sleepTimerEndClockMs by remember { mutableStateOf<Long?>(null) }

    // External Subtitle Picker
    val externalSubLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { subUri: Uri? ->
        if (subUri != null) {
            val pos = exoPlayer.currentPosition
            val mime = when (subUri.toString().substringAfterLast('.', "").lowercase()) {
                "vtt" -> MimeTypes.TEXT_VTT
                "ass", "ssa" -> MimeTypes.TEXT_SSA
                "ttml", "xml" -> MimeTypes.APPLICATION_TTML
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            val subConfig = MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType(mime)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            val updatedItem = MediaItem.Builder()
                .setUri(Uri.parse(video.uri))
                .setSubtitleConfigurations(listOf(subConfig))
                .build()
            exoPlayer.setMediaItem(updatedItem, pos)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
            gestureHudText = "External subtitle loaded"
        }
    }

    // Compute eye-comfort render state for video brightness, HUD luminance, and normal-brightness subtitles
    val eyeComfort = remember(
        videoBrightness,
        detectedHdrFormat,
        prefs.videoBrightnessBehavior,
        prefs.hdrBrightnessBehavior,
        prefs.subtitleEyeComfortCompensation
    ) {
        EyeComfortController.computeRenderState(
            requestedBrightness = videoBrightness,
            isHdrVideo = detectedHdrFormat.isHdr,
            sdrBehavior = prefs.videoBrightnessBehavior,
            hdrBehavior = prefs.hdrBrightnessBehavior,
            subtitleCompensationEnabled = prefs.subtitleEyeComfortCompensation
        )
    }

    val hudForegroundColor = remember(eyeComfort.hudLuminanceFactor) {
        EyeComfortController.applyLuminanceFactor(Color(0xFFEBEBEB), eyeComfort.hudLuminanceFactor)
    }
    val hudSecondaryColor = remember(eyeComfort.hudLuminanceFactor) {
        EyeComfortController.applyLuminanceFactor(Color(0xFFB8C0CC), eyeComfort.hudLuminanceFactor)
    }

    // Apply optional gentle window brightness override (restored cleanly on exit)
    LaunchedEffect(eyeComfort.windowBrightnessOverride) {
        val window = activity?.window ?: return@LaunchedEffect
        val lp = window.attributes
        lp.screenBrightness = eyeComfort.windowBrightnessOverride
            ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
    }

    // Immersive fullscreen bars & orientation
    DisposableEffect(activity) {
        val window = activity?.window
        if (window != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        when (prefs.orientationMode) {
            OrientationMode.LANDSCAPE -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            OrientationMode.PORTRAIT -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            OrientationMode.AUTO_SENSOR, OrientationMode.VIDEO_MATCH -> {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
        onDispose {
            val w = activity?.window
            if (w != null) {
                val controller = WindowInsetsControllerCompat(w, w.decorView)
                controller.show(WindowInsetsCompat.Type.systemBars())
                w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = lp
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Prepare media, attach Player.Listener, LoudnessEnhancer, and release cleanly on dispose
    DisposableEffect(exoPlayer, video.uid) {
        var loudnessEnhancer: LoudnessEnhancer? = null
        val startPos = if (prefs.resumeFromLastPosition && video.lastPositionMs > 5_000L &&
            (video.durationMs <= 0L || video.lastPositionMs < video.durationMs - 10_000L)
        ) {
            video.lastPositionMs
        } else {
            0L
        }

        val mediaItem = MediaItem.fromUri(Uri.parse(video.uri))
        exoPlayer.setMediaItem(mediaItem, startPos)
        exoPlayer.repeatMode = if (prefs.loopCurrentVideo) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        exoPlayer.setPlaybackSpeed(normalPlaybackSpeed)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        logbookRecorder.onSessionOpened(video.uid, video.displayName, startPos)

        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (playing) {
                    logbookRecorder.onResumed(exoPlayer.currentPosition)
                } else if (exoPlayer.playbackState == Player.STATE_READY) {
                    logbookRecorder.onPaused(exoPlayer.currentPosition)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    playbackError = null
                    durationMs = exoPlayer.duration.coerceAtLeast(video.durationMs)
                    if (prefs.audioBoostPercent > 0 && loudnessEnhancer == null) {
                        runCatching {
                            val sessionId = exoPlayer.audioSessionId
                            if (sessionId != C.AUDIO_SESSION_ID_UNSET) {
                                loudnessEnhancer = LoudnessEnhancer(sessionId).apply {
                                    setTargetGain(prefs.audioBoostPercent * 15) // safe mB gain
                                    enabled = true
                                }
                            }
                        }
                    }
                } else if (playbackState == Player.STATE_ENDED) {
                    completedNormally = true
                    logbookRecorder.onCompleted(exoPlayer.duration.coerceAtLeast(durationMs))
                    if (prefs.autoNextVideo && playlist.size > 1) {
                        val idx = playlist.indexOfFirst { it.uid == video.uid }
                        val next = playlist.getOrNull(idx + 1)
                        if (next != null) {
                            onSwitchVideo(next)
                        }
                    }
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                audioTracks = PlayerEngineFactory.extractAudioTracks(tracks)
                subtitleTracks = PlayerEngineFactory.extractSubtitleTracks(tracks)
                val videoFormat = exoPlayer.videoFormat
                if (prefs.hdrDetectionEnabled && videoFormat != null) {
                    val detected = HdrDetector.detectFromMedia3Format(videoFormat)
                    detectedHdrFormat = detected
                    hdrReport = HdrDetector.evaluateOutputStatus(
                        context = context,
                        sourceFormat = detected,
                        hdrStrictMode = prefs.hdrStrictMode,
                        hdrCompatibilityMode = prefs.hdrCompatibilityMode,
                        bitDepth = if (detected.isHdr) 10 else 8
                    )
                }
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (prefs.orientationMode == OrientationMode.VIDEO_MATCH && !isRotationLocked && videoSize.width > 0 && videoSize.height > 0) {
                    activity?.requestedOrientation = if (videoSize.width >= videoSize.height) {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                playbackError = "Playback error (${error.errorCodeName}): ${error.localizedMessage ?: "Unsupported codec or damaged file."}"
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            // Guaranteed restore of normal speed and clean session exit
            if (isLongPressSpeedActive) {
                isLongPressSpeedActive = false
            }
            val finalPos = exoPlayer.currentPosition.coerceAtLeast(0L)
            logbookRecorder.onSessionExited(finalPos)
            exoPlayer.removeListener(listener)
            runCatching { loudnessEnhancer?.release() }
            exoPlayer.release()
        }
    }

    // Lifecycle observer: pause when backgrounded (unless backgroundPlayback or PiP),
    // and ALWAYS restore normal speed if long-press 2x is interrupted by focus loss!
    DisposableEffect(lifecycleOwner, exoPlayer, isInPipMode, prefs.backgroundPlayback) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                if (isLongPressSpeedActive) {
                    isLongPressSpeedActive = false
                    exoPlayer.setPlaybackSpeed(normalPlaybackSpeed)
                }
                if (!prefs.backgroundPlayback && !isInPipMode) {
                    exoPlayer.pause()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Poll playback position, handle A-B repeat & sleep timer, auto-hide controls & gesture HUD
    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            val d = exoPlayer.duration
            if (d > 0L) durationMs = d

            val a = repeatPointAMs
            val b = repeatPointBMs
            if (a != null && b != null && b > a && currentPositionMs >= b) {
                exoPlayer.seekTo(a)
            }

            val sleepEnd = sleepTimerEndClockMs
            if (sleepEnd != null && System.currentTimeMillis() >= sleepEnd) {
                exoPlayer.pause()
                sleepTimerEndClockMs = null
                gestureHudText = "Sleep timer paused playback"
            }

            if (controlsVisible && isPlaying && System.currentTimeMillis() - lastInteractionMs > 3_500L) {
                controlsVisible = false
            }
            delay(250L)
        }
    }

    LaunchedEffect(gestureHudText) {
        if (gestureHudText != null) {
            delay(1_100L)
            gestureHudText = null
        }
    }

    val handleExit = {
        val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val dur = exoPlayer.duration.coerceAtLeast(durationMs)
        onExitPlayer(pos, dur, completedNormally)
    }

    BackHandler { handleExit() }

    val currentIndex = remember(playlist, video.uid) { playlist.indexOfFirst { it.uid == video.uid } }
    val prevVideo = remember(playlist, currentIndex) { playlist.getOrNull(currentIndex - 1) }
    val nextVideo = remember(playlist, currentIndex) { playlist.getOrNull(currentIndex + 1) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. Video Surface + Media3 SubtitleView (with eye-comfort subtitle luminance compensation!)
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    keepScreenOn = true
                }
            },
            update = { playerView ->
                playerView.player = exoPlayer
                playerView.resizeMode = when (displayMode) {
                    VideoDisplayMode.FIT_TO_SCREEN, VideoDisplayMode.ORIGINAL_SIZE -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    VideoDisplayMode.FIT_WIDTH -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                    VideoDisplayMode.FIT_HEIGHT -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
                    VideoDisplayMode.CROP, VideoDisplayMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    VideoDisplayMode.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                }

                // Eye-comfort subtitle styling: dims subtitle white luminance smoothly when
                // video brightness is high or HDR is active so subtitles NEVER look blinding!
                playerView.subtitleView?.let { subView ->
                    val compensatedFg = EyeComfortController.applyLuminanceToArgb(
                        baseArgb = prefs.subtitleColorArgb.toInt(),
                        luminanceFactor = eyeComfort.subtitleLuminanceFactor
                    )
                    val bgAlphaInt = ((prefs.subtitleBackgroundAlpha + eyeComfort.subtitleBackingBoost)
                        .coerceIn(0f, 0.85f) * 255f).roundToInt()
                    val bgColor = AndroidColor.argb(bgAlphaInt, 8, 10, 14)
                    val edgeType = if (prefs.subtitleOutlineEnabled) {
                        CaptionStyleCompat.EDGE_TYPE_OUTLINE
                    } else {
                        CaptionStyleCompat.EDGE_TYPE_NONE
                    }
                    subView.setStyle(
                        CaptionStyleCompat(
                            compensatedFg,
                            bgColor,
                            AndroidColor.TRANSPARENT,
                            edgeType,
                            AndroidColor.argb(200, 0, 0, 0),
                            null
                        )
                    )
                    subView.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.subtitleSizeSp)
                    subView.setBottomPaddingFraction(prefs.subtitleBottomPaddingFraction)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = if (displayMode == VideoDisplayMode.ZOOM || zoomScale != 1f) zoomScale else 1f,
                    scaleY = if (displayMode == VideoDisplayMode.ZOOM || zoomScale != 1f) zoomScale else 1f
                )
        )

        // 2. Video-surface-only dimming scrim (strictly below HUD controls)
        if (eyeComfort.videoDimScrimAlpha > 0.01f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = eyeComfort.videoDimScrimAlpha))
            )
        }

        // 3. Gesture Layer (disabled when screen is locked or in PiP)
        if (!isInPipMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(isScreenLocked, prefs.gestureDoubleTapSeek, prefs.gestureLongPressSpeed, prefs.doubleTapSeekSec, prefs.longPressSpeed) {
                        detectTapGestures(
                            onTap = {
                                controlsVisible = !controlsVisible
                                lastInteractionMs = System.currentTimeMillis()
                            },
                            onDoubleTap = { offset ->
                                if (isScreenLocked || !prefs.gestureDoubleTapSeek) return@detectTapGestures
                                val seekMs = prefs.doubleTapSeekSec * 1000L
                                if (offset.x < size.width / 2f) {
                                    exoPlayer.seekTo((exoPlayer.currentPosition - seekMs).coerceAtLeast(0L))
                                    gestureHudText = "Rewind -${prefs.doubleTapSeekSec}s"
                                } else {
                                    exoPlayer.seekTo((exoPlayer.currentPosition + seekMs).coerceAtMost(durationMs.coerceAtLeast(0L)))
                                    gestureHudText = "Forward +${prefs.doubleTapSeekSec}s"
                                }
                            },
                            onPress = {
                                // Long-press temporary 2x playback with guaranteed restore on release or cancel
                                if (isScreenLocked || !prefs.gestureLongPressSpeed) return@detectTapGestures
                                val longPressJob = coroutineScope.launch {
                                    delay(380L)
                                    isLongPressSpeedActive = true
                                    exoPlayer.setPlaybackSpeed(prefs.longPressSpeed)
                                    gestureHudText = "${String.format("%.1fx", prefs.longPressSpeed)} Speed (Hold)"
                                }
                                try {
                                    tryAwaitRelease()
                                } finally {
                                    longPressJob.cancel()
                                    if (isLongPressSpeedActive) {
                                        isLongPressSpeedActive = false
                                        exoPlayer.setPlaybackSpeed(normalPlaybackSpeed)
                                        gestureHudText = "${String.format("%.2gx", normalPlaybackSpeed)} Speed"
                                    }
                                }
                            }
                        )
                    }
                    .pointerInput(isScreenLocked, prefs.gestureHorizontalSeek, prefs.gestureSensitivity) {
                        var startPos = 0L
                        var deltaMs = 0L
                        detectHorizontalDragGestures(
                            onDragStart = {
                                if (isScreenLocked || !prefs.gestureHorizontalSeek) return@detectHorizontalDragGestures
                                startPos = exoPlayer.currentPosition
                                deltaMs = 0L
                            },
                            onHorizontalDrag = { _, dragAmount ->
                                if (isScreenLocked || !prefs.gestureHorizontalSeek) return@detectHorizontalDragGestures
                                deltaMs += (dragAmount * 90f * prefs.gestureSensitivity).toLong()
                                val target = (startPos + deltaMs).coerceIn(0L, durationMs.coerceAtLeast(0L))
                                val sign = if (deltaMs >= 0) "+" else "-"
                                gestureHudText = "${FormatUtils.formatDuration(target)} ($sign${abs(deltaMs / 1000L)}s)"
                            },
                            onDragEnd = {
                                if (isScreenLocked || !prefs.gestureHorizontalSeek) return@detectHorizontalDragGestures
                                val target = (startPos + deltaMs).coerceIn(0L, durationMs.coerceAtLeast(0L))
                                exoPlayer.seekTo(target)
                            }
                        )
                    }
                    .pointerInput(isScreenLocked, prefs.gestureBrightnessEnabled, prefs.gestureVerticalVolume, prefs.brightnessSensitivity) {
                        var isLeftSide = true
                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                isLeftSide = offset.x < size.width / 2f
                            },
                            onVerticalDrag = { _, dragAmount ->
                                if (isScreenLocked) return@detectVerticalDragGestures
                                val deltaNorm = (-dragAmount / size.height.coerceAtLeast(1)) * 1.4f
                                if (isLeftSide && prefs.gestureBrightnessEnabled) {
                                    val next = (videoBrightness + deltaNorm * prefs.brightnessSensitivity).coerceIn(0.05f, 1.0f)
                                    videoBrightness = next
                                    if (prefs.rememberBrightness) onSaveBrightness(next)
                                    gestureHudText = "Video Brightness ${(next * 100).roundToInt()}%"
                                } else if (!isLeftSide && prefs.gestureVerticalVolume) {
                                    val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                    val step = (deltaNorm * maxVolume * 2.2f).roundToInt()
                                    if (step != 0) {
                                        val nextVol = (curVol + step).coerceIn(0, maxVolume)
                                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                                        val pct = ((nextVol.toFloat() / maxVolume.toFloat()) * 100).roundToInt()
                                        gestureHudText = "Volume $pct%"
                                    }
                                }
                            }
                        )
                    }
                    .pointerInput(isScreenLocked, prefs.gesturePinchZoom, prefs.allowZoomBeyondCrop) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val event = awaitPointerEvent()
                                if (!isScreenLocked && prefs.gesturePinchZoom && event.changes.size >= 2) {
                                    val zoomChange = event.calculateZoom()
                                    if (abs(zoomChange - 1f) > 0.01f) {
                                        val maxZoom = if (prefs.allowZoomBeyondCrop) 2.5f else 1.5f
                                        zoomScale = (zoomScale * zoomChange).coerceIn(0.75f, maxZoom)
                                        displayMode = VideoDisplayMode.ZOOM
                                        gestureHudText = "Zoom ${(zoomScale * 100).roundToInt()}%"
                                    }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
            )
        }

        // 4. Center Gesture Feedback Pill
        gestureHudText?.let { text ->
            Surface(
                color = Color.Black.copy(alpha = 0.72f),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = text,
                    color = hudForegroundColor,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        // 5. Playback Error Recovery Overlay
        playbackError?.let { err ->
            Surface(
                color = Color(0xE6141821),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Unable to Play Video", color = Color(0xFFF07167), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(err, color = hudSecondaryColor, style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            playbackError = null
                            exoPlayer.prepare()
                            exoPlayer.playWhenReady = true
                        }) { Text("Retry") }
                        TextButton(onClick = handleExit) { Text("Close") }
                    }
                }
            }
        }

        // 6. Player Controls HUD (Eye-comfort luminance compensated!)
        AnimatedVisibility(
            visible = controlsVisible && !isInPipMode,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            if (isScreenLocked) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .padding(16.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = CircleShape,
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        IconButton(onClick = {
                            isScreenLocked = false
                            lastInteractionMs = System.currentTimeMillis()
                        }) {
                            Icon(Icons.Rounded.Lock, contentDescription = "Unlock screen", tint = hudForegroundColor)
                        }
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Top Controls Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.78f), Color.Transparent)))
                            .statusBarsPadding()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = handleExit) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = hudForegroundColor)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = video.displayName.substringBeforeLast('.'),
                                color = hudForegroundColor,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (prefs.showHdrIndicator) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Surface(
                                    color = if (detectedHdrFormat.isHdr) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.clickable {
                                        lastInteractionMs = System.currentTimeMillis()
                                        showHdrInfoDialog = true
                                    }
                                ) {
                                    Text(
                                        text = detectedHdrFormat.badgeLabel,
                                        color = hudForegroundColor,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        IconButton(onClick = {
                            lastInteractionMs = System.currentTimeMillis()
                            showSubtitleDialog = true
                        }) {
                            Icon(Icons.Rounded.Subtitles, contentDescription = "Subtitles", tint = hudForegroundColor)
                        }
                        IconButton(onClick = {
                            lastInteractionMs = System.currentTimeMillis()
                            showAudioDialog = true
                        }) {
                            Icon(Icons.Rounded.Audiotrack, contentDescription = "Audio tracks", tint = hudForegroundColor)
                        }
                        Box {
                            IconButton(onClick = {
                                lastInteractionMs = System.currentTimeMillis()
                                showOverflowMenu = true
                            }) {
                                Icon(Icons.Rounded.MoreVert, contentDescription = "More options", tint = hudForegroundColor)
                            }
                            DropdownMenu(expanded = showOverflowMenu, onDismissRequest = { showOverflowMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Display Mode (${displayMode.label})") },
                                    onClick = { showOverflowMenu = false; showDisplayModeDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Screen Lock") },
                                    leadingIcon = { Icon(Icons.Rounded.LockOpen, contentDescription = null) },
                                    onClick = { showOverflowMenu = false; isScreenLocked = true }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (isRotationLocked) "Unlock Rotation" else "Lock Rotation") },
                                    leadingIcon = { Icon(Icons.Rounded.ScreenRotation, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        isRotationLocked = !isRotationLocked
                                        activity?.requestedOrientation = if (isRotationLocked) {
                                            ActivityInfo.SCREEN_ORIENTATION_LOCKED
                                        } else {
                                            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Picture-in-Picture") },
                                    onClick = {
                                        showOverflowMenu = false
                                        runCatching {
                                            val aspect = Rational(16, 9)
                                            val params = PictureInPictureParams.Builder().setAspectRatio(aspect).build()
                                            activity?.enterPictureInPictureMode(params)
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Sleep Timer") },
                                    onClick = { showOverflowMenu = false; showSleepTimerDialog = true }
                                )
                                DropdownMenuItem(
                                    text = {
                                        val abText = when {
                                            repeatPointAMs == null -> "A-B Repeat: Set Point A"
                                            repeatPointBMs == null -> "A-B Repeat: Set Point B"
                                            else -> "A-B Repeat: Clear"
                                        }
                                        Text(abText)
                                    },
                                    onClick = {
                                        showOverflowMenu = false
                                        when {
                                            repeatPointAMs == null -> {
                                                repeatPointAMs = exoPlayer.currentPosition
                                                gestureHudText = "Repeat A set at ${FormatUtils.formatDuration(exoPlayer.currentPosition)}"
                                            }
                                            repeatPointBMs == null -> {
                                                repeatPointBMs = exoPlayer.currentPosition
                                                gestureHudText = "A-B Repeat active"
                                            }
                                            else -> {
                                                repeatPointAMs = null
                                                repeatPointBMs = null
                                                gestureHudText = "A-B Repeat cleared"
                                            }
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Video Info & Logbook") },
                                    leadingIcon = { Icon(Icons.Outlined.Info, contentDescription = null) },
                                    onClick = { showOverflowMenu = false; onOpenVideoInfo(video) }
                                )
                            }
                        }
                    }

                    // Center Transport Controls
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (prevVideo != null) {
                            IconButton(onClick = { onSwitchVideo(prevVideo) }) {
                                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous video", tint = hudForegroundColor, modifier = Modifier.size(32.dp))
                            }
                        }
                        IconButton(
                            onClick = {
                                lastInteractionMs = System.currentTimeMillis()
                                exoPlayer.seekTo((exoPlayer.currentPosition - prefs.seekIntervalSec * 1000L).coerceAtLeast(0L))
                            },
                            modifier = Modifier.size(52.dp)
                        ) {
                            Icon(Icons.Rounded.Replay10, contentDescription = "Rewind", tint = hudForegroundColor, modifier = Modifier.size(36.dp))
                        }
                        Surface(
                            color = Color.Black.copy(alpha = 0.52f),
                            shape = CircleShape,
                            modifier = Modifier.size(64.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    lastInteractionMs = System.currentTimeMillis()
                                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                }
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    tint = hudForegroundColor,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                lastInteractionMs = System.currentTimeMillis()
                                exoPlayer.seekTo((exoPlayer.currentPosition + prefs.seekIntervalSec * 1000L).coerceAtMost(durationMs.coerceAtLeast(0L)))
                            },
                            modifier = Modifier.size(52.dp)
                        ) {
                            Icon(Icons.Rounded.Forward10, contentDescription = "Forward", tint = hudForegroundColor, modifier = Modifier.size(36.dp))
                        }
                        if (nextVideo != null) {
                            IconButton(onClick = { onSwitchVideo(nextVideo) }) {
                                Icon(Icons.Rounded.SkipNext, contentDescription = "Next video", tint = hudForegroundColor, modifier = Modifier.size(32.dp))
                            }
                        }
                    }

                    // Bottom Timeline & Essential Controls
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.82f))))
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Slider(
                            value = if (durationMs > 0L) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f,
                            onValueChange = { frac ->
                                lastInteractionMs = System.currentTimeMillis()
                                val target = (frac * durationMs).toLong()
                                currentPositionMs = target
                                exoPlayer.seekTo(target)
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = hudForegroundColor,
                                activeTrackColor = EyeComfortController.applyLuminanceFactor(
                                    MaterialTheme.colorScheme.primary,
                                    eyeComfort.hudLuminanceFactor
                                ),
                                inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                            )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${FormatUtils.formatDuration(currentPositionMs)} / ${FormatUtils.formatDuration(durationMs)}",
                                color = hudForegroundColor,
                                style = MaterialTheme.typography.labelLarge
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = {
                                    lastInteractionMs = System.currentTimeMillis()
                                    showSpeedDialog = true
                                }) {
                                    Icon(Icons.Rounded.Speed, contentDescription = null, tint = hudForegroundColor, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${String.format("%.2gx", normalPlaybackSpeed)}", color = hudForegroundColor)
                                }
                                IconButton(onClick = {
                                    lastInteractionMs = System.currentTimeMillis()
                                    val isLandscape = activity?.resources?.configuration?.orientation ==
                                        android.content.res.Configuration.ORIENTATION_LANDSCAPE
                                    activity?.requestedOrientation = if (isLandscape) {
                                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                                    } else {
                                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                    }
                                }) {
                                    Icon(Icons.Rounded.Fullscreen, contentDescription = "Toggle fullscreen orientation", tint = hudForegroundColor)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- Player Dialogs ---
    if (showSpeedDialog) {
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Playback Speed") },
            text = {
                Column {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f).forEach { speed ->
                        TextButton(
                            onClick = {
                                normalPlaybackSpeed = speed
                                exoPlayer.setPlaybackSpeed(speed)
                                showSpeedDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (speed == normalPlaybackSpeed) "${speed}x (Active)" else "${speed}x",
                                fontWeight = if (speed == normalPlaybackSpeed) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showSpeedDialog = false }) { Text("Close") } }
        )
    }

    if (showAudioDialog) {
        AlertDialog(
            onDismissRequest = { showAudioDialog = false },
            title = { Text("Audio Track") },
            text = {
                Column {
                    if (audioTracks.isEmpty()) {
                        Text("No selectable embedded audio tracks detected.")
                    } else {
                        audioTracks.forEach { track ->
                            TextButton(
                                onClick = {
                                    PlayerEngineFactory.selectTrack(exoPlayer, C.TRACK_TYPE_AUDIO, track)
                                    showAudioDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (track.isSelected) "• ${track.label}" else track.label)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showAudioDialog = false }) { Text("Close") } }
        )
    }

    if (showSubtitleDialog) {
        AlertDialog(
            onDismissRequest = { showSubtitleDialog = false },
            title = { Text("Subtitles") },
            text = {
                Column {
                    TextButton(
                        onClick = {
                            PlayerEngineFactory.selectTrack(exoPlayer, C.TRACK_TYPE_TEXT, null)
                            showSubtitleDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Off (Disable Subtitles)") }
                    subtitleTracks.forEach { track ->
                        TextButton(
                            onClick = {
                                PlayerEngineFactory.selectTrack(exoPlayer, C.TRACK_TYPE_TEXT, track)
                                showSubtitleDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (track.isSelected) "• ${track.label}" else track.label)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = {
                            showSubtitleDialog = false
                            externalSubLauncher.launch(arrayOf("*/*"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Load External Subtitle (.srt / .vtt / .ass)")
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showSubtitleDialog = false }) { Text("Close") } }
        )
    }

    if (showDisplayModeDialog) {
        AlertDialog(
            onDismissRequest = { showDisplayModeDialog = false },
            title = { Text("Video Display Mode") },
            text = {
                Column {
                    VideoDisplayMode.entries.forEach { mode ->
                        TextButton(
                            onClick = {
                                displayMode = mode
                                if (mode != VideoDisplayMode.ZOOM) zoomScale = 1.0f
                                showDisplayModeDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (mode == displayMode) "• ${mode.label}" else mode.label)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showDisplayModeDialog = false }) { Text("Close") } }
        )
    }

    if (showHdrInfoDialog) {
        AlertDialog(
            onDismissRequest = { showHdrInfoDialog = false },
            title = { Text("HDR / Display Output Status") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Source Metadata: ${hdrReport.sourceFormat.badgeLabel}", fontWeight = FontWeight.SemiBold)
                    Text("Display Output Mode: ${hdrReport.outputMode.label}")
                    Text("Bit Depth: ${hdrReport.bitDepth}-bit")
                    Text(hdrReport.detailMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showHdrInfoDialog = false }) { Text("OK") } }
        )
    }

    if (showSleepTimerDialog) {
        AlertDialog(
            onDismissRequest = { showSleepTimerDialog = false },
            title = { Text("Sleep Timer") },
            text = {
                Column {
                    listOf(0, 15, 30, 45, 60).forEach { mins ->
                        TextButton(
                            onClick = {
                                sleepTimerEndClockMs = if (mins == 0) null else System.currentTimeMillis() + mins * 60_000L
                                gestureHudText = if (mins == 0) "Sleep timer off" else "Sleep timer: $mins min"
                                showSleepTimerDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (mins == 0) "Off" else "$mins minutes")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showSleepTimerDialog = false }) { Text("Close") } }
        )
    }
}
