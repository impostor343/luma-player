package com.lumaplayer.app.domain

data class ReviewThresholdConfig(
    val autoPromptEnabled: Boolean = true,
    val longVideoRemainingMinutes: Int = 10,  // For videos > 60 min
    val mediumVideoRemainingMinutes: Int = 2, // For videos 20..60 min (~30 min)
    val shortVideoMinPercent: Int = 90        // For videos < 20 min
)

object ReviewTriggerEngine {

    /**
     * Decides whether the automatic review prompt should appear when a video completes
     * or when the user exits near the end.
     */
    fun shouldPromptForReview(
        durationMs: Long,
        exitPositionMs: Long,
        completedNormally: Boolean,
        alreadyReviewed: Boolean,
        previouslyDismissed: Boolean,
        config: ReviewThresholdConfig
    ): Boolean {
        if (!config.autoPromptEnabled) return false
        if (alreadyReviewed || previouslyDismissed) return false
        if (durationMs <= 0L) return completedNormally

        if (completedNormally) return true

        val safePos = exitPositionMs.coerceIn(0L, durationMs)
        val remainingMs = durationMs - safePos
        val durationMin = durationMs / 60_000.0

        // Never prompt if exited very early (< 50% watched)
        if (safePos < durationMs * 0.50) return false

        return when {
            durationMin > 60.0 -> {
                val thresholdMs = config.longVideoRemainingMinutes.coerceIn(1, 30) * 60_000L
                remainingMs <= thresholdMs
            }
            durationMin >= 20.0 -> {
                val thresholdMs = config.mediumVideoRemainingMinutes.coerceIn(1, 10) * 60_000L
                remainingMs <= thresholdMs
            }
            else -> {
                val pct = (safePos.toDouble() / durationMs.toDouble()) * 100.0
                pct >= config.shortVideoMinPercent.coerceIn(70, 99)
            }
        }
    }
}
