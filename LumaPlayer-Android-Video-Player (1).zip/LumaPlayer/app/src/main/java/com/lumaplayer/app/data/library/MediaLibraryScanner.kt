package com.lumaplayer.app.data.library

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import com.lumaplayer.app.data.db.VideoDao
import com.lumaplayer.app.data.db.VideoEntity
import com.lumaplayer.app.domain.HdrDetector
import com.lumaplayer.app.domain.HdrFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

class MediaLibraryScanner(
    private val context: Context,
    private val videoDao: VideoDao
) {

    suspend fun scanAll(
        safFolderUris: Set<String>,
        includeHiddenFolders: Boolean
    ): Int = withContext(Dispatchers.IO) {
        val existingList = videoDao.getAllVideosOnce()
        val existingByUri = existingList.associateBy { it.uri }
        val existingByMediaStoreId = existingList.mapNotNull { v ->
            v.mediaStoreId?.let { id -> id to v }
        }.toMap()
        val existingByFingerprint = existingList.associateBy { "${it.sizeBytes}:${it.durationMs}" }

        val discovered = mutableListOf<VideoEntity>()
        val discoveredUids = mutableSetOf<String>()

        // 1. Scan MediaStore.Video.Media
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.RELATIVE_PATH,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.MIME_TYPE
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.RELATIVE_PATH)
            val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val name = cursor.getString(nameCol) ?: "Video_$id"
                val relPath = cursor.getString(pathCol) ?: "Internal Storage/"
                val bucket = cursor.getString(bucketCol) ?: extractFolderName(relPath)
                if (!includeHiddenFolders && isHiddenPath(relPath)) continue

                val size = cursor.getLong(sizeCol)
                val duration = cursor.getLong(durCol)
                var width = cursor.getInt(widthCol)
                var height = cursor.getInt(heightCol)
                val dateAdded = cursor.getLong(dateCol)
                val mime = cursor.getString(mimeCol) ?: "video/*"
                val contentUri = ContentUris.withAppendedId(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    id
                ).toString()

                val existing = existingByMediaStoreId[id]
                    ?: existingByUri[contentUri]
                    ?: existingByFingerprint["$size:$duration"]

                val uid = existing?.uid ?: generateStableUid("ms:$id:$size:$duration")
                val meta = if (existing != null && existing.videoCodec.isNotBlank() && existing.width > 0) {
                    ExtractedMeta(
                        width = if (width > 0) width else existing.width,
                        height = if (height > 0) height else existing.height,
                        durationMs = if (duration > 0) duration else existing.durationMs,
                        frameRate = existing.frameRate,
                        videoCodec = existing.videoCodec,
                        audioCodec = existing.audioCodec,
                        bitDepth = existing.bitDepth,
                        hdrType = existing.hdrType,
                        colorInfoText = existing.colorInfoText
                    )
                } else {
                    extractMetadataSafe(Uri.parse(contentUri), mime, width, height, duration)
                }

                val entity = VideoEntity(
                    uid = uid,
                    mediaStoreId = id,
                    uri = contentUri,
                    displayName = name,
                    folderPath = relPath.trimEnd('/'),
                    folderName = bucket.ifBlank { "Internal Storage" },
                    sizeBytes = size,
                    durationMs = meta.durationMs,
                    width = meta.width,
                    height = meta.height,
                    frameRate = meta.frameRate,
                    videoCodec = meta.videoCodec,
                    audioCodec = meta.audioCodec,
                    bitDepth = meta.bitDepth,
                    hdrType = meta.hdrType,
                    colorInfoText = meta.colorInfoText,
                    dateAddedSec = dateAdded,
                    lastPositionMs = existing?.lastPositionMs ?: 0L,
                    lastPlayedAtMs = existing?.lastPlayedAtMs ?: 0L,
                    isFavourite = existing?.isFavourite ?: false,
                    isAvailable = true,
                    reviewDismissed = existing?.reviewDismissed ?: false
                )
                discovered.add(entity)
                discoveredUids.add(uid)
            }
        }

        // 2. Scan user-selected SAF folders
        for (treeUriStr in safFolderUris) {
            runCatching {
                val treeUri = Uri.parse(treeUriStr)
                val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@runCatching
                val folderLabel = root.name ?: "Selected Folder"
                collectSafVideos(
                    dir = root,
                    folderPath = "SAF/$folderLabel",
                    folderName = folderLabel,
                    existingByUri = existingByUri,
                    existingByFingerprint = existingByFingerprint,
                    out = discovered,
                    discoveredUids = discoveredUids
                )
            }
        }

        if (discovered.isNotEmpty()) {
            videoDao.upsertVideos(discovered)
        }

        // 3. Mark missing files as unavailable WITHOUT deleting records, reviews, or logbook history
        for (old in existingList) {
            if (old.uid !in discoveredUids && old.isAvailable) {
                videoDao.setAvailable(old.uid, false)
            }
        }

        discovered.size
    }

    /**
     * Imports a single video picked via Android's Storage Access Framework file picker
     * or opened via ACTION_VIEW intent, returning its persisted VideoEntity.
     */
    suspend fun registerExternalUri(uri: Uri): VideoEntity = withContext(Dispatchers.IO) {
        val uriString = uri.toString()
        videoDao.getVideoByUri(uriString)?.let { existing ->
            if (!existing.isAvailable) {
                videoDao.setAvailable(existing.uid, true)
                return@withContext existing.copy(isAvailable = true)
            }
            return@withContext existing
        }

        val doc = runCatching { DocumentFile.fromSingleUri(context, uri) }.getOrNull()
        val displayName = doc?.name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "External Video"
        val sizeBytes = doc?.length() ?: 0L
        val mime = doc?.type ?: context.contentResolver.getType(uri) ?: "video/*"
        val meta = extractMetadataSafe(uri, mime, 0, 0, 0L)
        val uid = generateStableUid("ext:$uriString:$sizeBytes:${meta.durationMs}")

        val entity = VideoEntity(
            uid = uid,
            mediaStoreId = null,
            uri = uriString,
            displayName = displayName,
            folderPath = "External Picker",
            folderName = "External Picker",
            sizeBytes = sizeBytes,
            durationMs = meta.durationMs,
            width = meta.width,
            height = meta.height,
            frameRate = meta.frameRate,
            videoCodec = meta.videoCodec,
            audioCodec = meta.audioCodec,
            bitDepth = meta.bitDepth,
            hdrType = meta.hdrType,
            colorInfoText = meta.colorInfoText,
            dateAddedSec = System.currentTimeMillis() / 1000L,
            isAvailable = true
        )
        videoDao.upsertVideo(entity)
        entity
    }

    private fun collectSafVideos(
        dir: DocumentFile,
        folderPath: String,
        folderName: String,
        existingByUri: Map<String, VideoEntity>,
        existingByFingerprint: Map<String, VideoEntity>,
        out: MutableList<VideoEntity>,
        discoveredUids: MutableSet<String>
    ) {
        val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
        for (child in children) {
            if (child.isDirectory) {
                val subName = child.name ?: continue
                collectSafVideos(
                    dir = child,
                    folderPath = "$folderPath/$subName",
                    folderName = subName,
                    existingByUri = existingByUri,
                    existingByFingerprint = existingByFingerprint,
                    out = out,
                    discoveredUids = discoveredUids
                )
            } else if (child.isFile) {
                val type = child.type.orEmpty()
                val name = child.name ?: continue
                if (!type.startsWith("video/") && !hasVideoExtension(name)) continue
                val uriStr = child.uri.toString()
                val size = child.length()
                val existing = existingByUri[uriStr]
                val meta = if (existing != null && existing.width > 0) {
                    ExtractedMeta(
                        existing.width, existing.height, existing.durationMs,
                        existing.frameRate, existing.videoCodec, existing.audioCodec,
                        existing.bitDepth, existing.hdrType, existing.colorInfoText
                    )
                } else {
                    extractMetadataSafe(child.uri, type, 0, 0, 0L)
                }
                val matched = existing ?: existingByFingerprint["$size:${meta.durationMs}"]
                val uid = matched?.uid ?: generateStableUid("saf:$uriStr:$size")
                if (uid in discoveredUids) continue

                out.add(
                    VideoEntity(
                        uid = uid,
                        mediaStoreId = null,
                        uri = uriStr,
                        displayName = name,
                        folderPath = folderPath,
                        folderName = folderName,
                        sizeBytes = size,
                        durationMs = meta.durationMs,
                        width = meta.width,
                        height = meta.height,
                        frameRate = meta.frameRate,
                        videoCodec = meta.videoCodec,
                        audioCodec = meta.audioCodec,
                        bitDepth = meta.bitDepth,
                        hdrType = meta.hdrType,
                        colorInfoText = meta.colorInfoText,
                        dateAddedSec = (child.lastModified() / 1000L).coerceAtLeast(1L),
                        lastPositionMs = matched?.lastPositionMs ?: 0L,
                        lastPlayedAtMs = matched?.lastPlayedAtMs ?: 0L,
                        isFavourite = matched?.isFavourite ?: false,
                        isAvailable = true,
                        reviewDismissed = matched?.reviewDismissed ?: false
                    )
                )
                discoveredUids.add(uid)
            }
        }
    }

    private data class ExtractedMeta(
        val width: Int,
        val height: Int,
        val durationMs: Long,
        val frameRate: Float,
        val videoCodec: String,
        val audioCodec: String,
        val bitDepth: Int,
        val hdrType: String,
        val colorInfoText: String
    )

    private fun extractMetadataSafe(
        uri: Uri,
        mime: String,
        fallbackWidth: Int,
        fallbackHeight: Int,
        fallbackDuration: Long
    ): ExtractedMeta {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                ?: fallbackWidth
            val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                ?: fallbackHeight
            val dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: fallbackDuration
            val fps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()
                ?: 0f
            val colorTransfer = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COLOR_TRANSFER)?.toIntOrNull()
            val colorStandard = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COLOR_STANDARD)?.toIntOrNull()
            val bitDepth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE)?.toIntOrNull()
                ?: if (colorTransfer == android.media.MediaFormat.COLOR_TRANSFER_ST2084 ||
                    colorTransfer == android.media.MediaFormat.COLOR_TRANSFER_HLG
                ) 10 else 8
            val detectedMime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: mime

            val hdrFormat = HdrDetector.detectFromMetadataRetriever(colorTransfer, detectedMime, bitDepth)
            val transferLabel = when (colorTransfer) {
                android.media.MediaFormat.COLOR_TRANSFER_ST2084 -> "ST.2084 (PQ)"
                android.media.MediaFormat.COLOR_TRANSFER_HLG -> "HLG"
                android.media.MediaFormat.COLOR_TRANSFER_SDR_VIDEO -> "SDR (BT.1886)"
                else -> "Standard"
            }
            val standardLabel = when (colorStandard) {
                android.media.MediaFormat.COLOR_STANDARD_BT2020 -> "BT.2020"
                android.media.MediaFormat.COLOR_STANDARD_BT709 -> "BT.709"
                android.media.MediaFormat.COLOR_STANDARD_BT601_NTSC,
                android.media.MediaFormat.COLOR_STANDARD_BT601_PAL -> "BT.601"
                else -> "Unknown"
            }

            ExtractedMeta(
                width = w,
                height = h,
                durationMs = dur,
                frameRate = fps,
                videoCodec = detectedMime.substringAfter('/').uppercase().ifBlank { "VIDEO" },
                audioCodec = "Embedded",
                bitDepth = bitDepth,
                hdrType = hdrFormat.name,
                colorInfoText = "$standardLabel / $transferLabel"
            )
        } catch (_: Throwable) {
            ExtractedMeta(
                width = fallbackWidth,
                height = fallbackHeight,
                durationMs = fallbackDuration,
                frameRate = 0f,
                videoCodec = mime.substringAfter('/').uppercase().ifBlank { "VIDEO" },
                audioCodec = "Unknown",
                bitDepth = 8,
                hdrType = HdrFormat.SDR.name,
                colorInfoText = "Unavailable"
            )
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun extractFolderName(relPath: String): String {
        return relPath.trimEnd('/').substringAfterLast('/').ifBlank { "Internal Storage" }
    }

    private fun isHiddenPath(relPath: String): Boolean {
        return relPath.split('/').any { it.startsWith(".") }
    }

    private fun hasVideoExtension(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("mp4", "mkv", "mov", "avi", "webm", "flv", "ts", "mts", "m2ts", "3gp", "m4v", "mpg", "mpeg", "wmv")
    }

    private fun generateStableUid(seed: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        return digest.take(12).joinToString("") { "%02x".format(it) }
    }
}
