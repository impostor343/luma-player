package com.lumaplayer.app.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lumaplayer.app.data.db.VideoEntity
import com.lumaplayer.app.data.library.VideoThumbnailLoader
import com.lumaplayer.app.data.prefs.AppPreferences
import com.lumaplayer.app.data.prefs.LibrarySortOrder
import com.lumaplayer.app.domain.HdrFormat
import com.lumaplayer.app.ui.components.VideoGridCard
import com.lumaplayer.app.ui.components.VideoListRow

private enum class HomeFilter(val label: String) {
    ALL("All"),
    HDR_ONLY("HDR"),
    FAVOURITES("Favourites"),
    RECENTLY_PLAYED("Recent")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    allVideos: List<VideoEntity>,
    continueWatching: List<VideoEntity>,
    recentlyPlayed: List<VideoEntity>,
    prefs: AppPreferences,
    hasStoragePermission: Boolean,
    isScanning: Boolean,
    thumbnailLoader: VideoThumbnailLoader,
    onRequestPermission: () -> Unit,
    onRescan: () -> Unit,
    onToggleGrid: () -> Unit,
    onChangeSort: (LibrarySortOrder) -> Unit,
    onOpenVideoPicker: () -> Unit,
    onPlayVideo: (VideoEntity) -> Unit,
    onOpenInfo: (VideoEntity) -> Unit,
    onOpenFolder: (String) -> Unit
) {
    var searchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var activeFilter by remember { mutableStateOf(HomeFilter.ALL) }

    val filteredVideos = remember(allVideos, searchQuery, activeFilter, prefs.sortOrder) {
        val base = allVideos.filter { it.isAvailable }.filter { video ->
            val matchesQuery = searchQuery.isBlank() ||
                video.displayName.contains(searchQuery, ignoreCase = true) ||
                video.folderName.contains(searchQuery, ignoreCase = true)
            val matchesFilter = when (activeFilter) {
                HomeFilter.ALL -> true
                HomeFilter.HDR_ONLY -> HdrFormat.fromStored(video.hdrType).isHdr
                HomeFilter.FAVOURITES -> video.isFavourite
                HomeFilter.RECENTLY_PLAYED -> video.lastPlayedAtMs > 0L
            }
            matchesQuery && matchesFilter
        }
        when (prefs.sortOrder) {
            LibrarySortOrder.DATE_ADDED_DESC -> base.sortedByDescending { it.dateAddedSec }
            LibrarySortOrder.NAME_ASC -> base.sortedBy { it.displayName.lowercase() }
            LibrarySortOrder.DURATION_DESC -> base.sortedByDescending { it.durationMs }
            LibrarySortOrder.SIZE_DESC -> base.sortedByDescending { it.sizeBytes }
            LibrarySortOrder.RECENTLY_PLAYED -> base.sortedByDescending { it.lastPlayedAtMs }
        }
    }

    val folderSummary = remember(allVideos) {
        allVideos.filter { it.isAvailable }
            .groupBy { it.folderPath }
            .entries
            .sortedByDescending { it.value.size }
            .take(8)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searchVisible) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search videos or folders") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text("LumaPlayer", fontWeight = FontWeight.SemiBold)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        searchVisible = !searchVisible
                        if (!searchVisible) searchQuery = ""
                    }) {
                        Icon(
                            imageVector = if (searchVisible) Icons.Rounded.Close else Icons.Rounded.Search,
                            contentDescription = "Search"
                        )
                    }
                    IconButton(onClick = onToggleGrid) {
                        Icon(
                            imageVector = if (prefs.gridViewEnabled) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView,
                            contentDescription = "Toggle layout"
                        )
                    }
                    Box {
                        IconButton(onClick = { sortMenuExpanded = true }) {
                            Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = "Sort")
                        }
                        DropdownMenu(
                            expanded = sortMenuExpanded,
                            onDismissRequest = { sortMenuExpanded = false }
                        ) {
                            LibrarySortOrder.entries.forEach { order ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = order.label,
                                            fontWeight = if (order == prefs.sortOrder) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        sortMenuExpanded = false
                                        onChangeSort(order)
                                    }
                                )
                            }
                        }
                    }
                    IconButton(onClick = onRescan, enabled = !isScanning) {
                        if (isScanning) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Rescan videos")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenVideoPicker,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = "Open video file")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!hasStoragePermission) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Allow video library access",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Grant media video access so LumaPlayer can automatically discover your local videos and folders, or open any single video manually using the picker.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = onRequestPermission) {
                                    Text("Grant Access")
                                }
                                OutlinedButton(onClick = onOpenVideoPicker) {
                                    Text("Open File")
                                }
                            }
                        }
                    }
                }
            }

            if (prefs.continueWatchingEnabled && continueWatching.isNotEmpty() && searchQuery.isBlank() && activeFilter == HomeFilter.ALL) {
                item {
                    SectionHeader("Continue Watching")
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(continueWatching, key = { "cw_${it.uid}" }) { video ->
                            VideoGridCard(
                                video = video,
                                thumbnailLoader = thumbnailLoader,
                                onPlayClick = { onPlayVideo(video) },
                                onInfoClick = { onOpenInfo(video) },
                                modifier = Modifier.width(210.dp)
                            )
                        }
                    }
                }
            }

            if (recentlyPlayed.isNotEmpty() && searchQuery.isBlank() && activeFilter == HomeFilter.ALL) {
                item {
                    SectionHeader("Recently Played")
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recentlyPlayed.take(10), key = { "rp_${it.uid}" }) { video ->
                            VideoGridCard(
                                video = video,
                                thumbnailLoader = thumbnailLoader,
                                onPlayClick = { onPlayVideo(video) },
                                onInfoClick = { onOpenInfo(video) },
                                modifier = Modifier.width(196.dp)
                            )
                        }
                    }
                }
            }

            if (folderSummary.isNotEmpty() && searchQuery.isBlank() && activeFilter == HomeFilter.ALL) {
                item {
                    SectionHeader("Folders")
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(folderSummary, key = { it.key }) { (path, videos) ->
                            val folderName = videos.firstOrNull()?.folderName ?: "Folder"
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .width(148.dp)
                                    .clickable { onOpenFolder(path) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Folder,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = folderName,
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${videos.size} video${if (videos.size == 1) "" else "s"}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Filter Chips + All Videos Header
            item {
                SectionHeader("All Videos (${filteredVideos.size})")
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(HomeFilter.entries) { filter ->
                        FilterChip(
                            selected = activeFilter == filter,
                            onClick = { activeFilter = filter },
                            label = { Text(filter.label) }
                        )
                    }
                }
            }

            if (filteredVideos.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (isScanning) "Scanning local videos..." else "No matching videos found",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(onClick = onOpenVideoPicker) {
                                Text("Open Video Manually")
                            }
                        }
                    }
                }
            } else if (prefs.gridViewEnabled) {
                val cols = prefs.gridColumns.coerceIn(2, 3)
                val rows = filteredVideos.chunked(cols)
                items(rows, key = { row -> row.joinToString("_") { it.uid } }) { rowVideos ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowVideos.forEach { video ->
                            VideoGridCard(
                                video = video,
                                thumbnailLoader = thumbnailLoader,
                                onPlayClick = { onPlayVideo(video) },
                                onInfoClick = { onOpenInfo(video) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(cols - rowVideos.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            } else {
                items(filteredVideos, key = { it.uid }) { video ->
                    VideoListRow(
                        video = video,
                        thumbnailLoader = thumbnailLoader,
                        onPlayClick = { onPlayVideo(video) },
                        onInfoClick = { onOpenInfo(video) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onBackground
    )
}
