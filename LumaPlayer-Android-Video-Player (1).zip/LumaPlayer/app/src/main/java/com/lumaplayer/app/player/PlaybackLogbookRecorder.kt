package com.lumaplayer.app.player

import com.lumaplayer.app.data.db.PlaybackEventEntity
import com.lumaplayer.app.data.db.PlaybackLogDao
import com.lumaplayer.app.data.db.PlaybackSessionEntity
import com.lumaplayer.app.data.db.VideoDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Records detailed per-video playback logbook sessions and events.
 * Strictly separates actual wall-clock timestamps from video timeline positions
 * and tracks active viewing duration separately from paused elapsed time.
 */
class PlaybackLogbookRecorder(
    private val logDao: PlaybackLogDao,
    private val videoDao: VideoDao,
    private val scope: CoroutineScope
) {
    private var activeSessionId: Long? = null
    private var activeVideoUid: String? = null
    private var activeVideoTitle: String = ""
    private var openedAtClockMs: Long = 0L
    private var startedAtPositionMs: Long = 0L

    private var activePlaySegmentStartClockMs: Long? = null
    private var accumulatedViewingTimeMs: Long = 0L
    private var completedInSession: Boolean = false

    fun onSessionOpened(videoUid: String, videoTitle: String, startPositionMs: Long) {
        val now = System.currentTimeMillis()
        activeVideoUid = videoUid
        activeVideoTitle = videoTitle
        openedAtClockMs = now
        startedAtPositionMs = startPositionMs.coerceAtLeast(0L)
        accumulatedViewingTimeMs = 0L
        activePlaySegmentStartClockMs = now
        completedInSession = false

        scope.launch(Dispatchers.IO) {
            val session = PlaybackSessionEntity(
                videoUid = videoUid,
                videoTitleSnapshot = videoTitle,
                openedAtClockMs = now,
                startedAtPositionMs = startedAtPositionMs
            )
            val id = logDao.insertSession(session)
            activeSessionId = id
            logDao.insertEvent(
                PlaybackEventEntity(
                    sessionId = id,
                    videoUid = videoUid,
                    eventType = "OPENED",
                    clockTimestampMs = now,
                    videoPositionMs = startedAtPositionMs
                )
            )
        }
    }

    fun onPaused(videoPositionMs: Long) {
        val now = System.currentTimeMillis()
        val segStart = activePlaySegmentStartClockMs
        if (segStart != null) {
            accumulatedViewingTimeMs += (now - segStart).coerceAtLeast(0L)
            activePlaySegmentStartClockMs = null
        }
        val sid = activeSessionId ?: return
        val uid = activeVideoUid ?: return
        val safePos = videoPositionMs.coerceAtLeast(0L)
        scope.launch(Dispatchers.IO) {
            logDao.insertEvent(
                PlaybackEventEntity(
                    sessionId = sid,
                    videoUid = uid,
                    eventType = "PAUSED",
                    clockTimestampMs = now,
                    videoPositionMs = safePos
                )
            )
            videoDao.updatePlaybackPosition(uid, safePos, now)
        }
    }

    fun onResumed(videoPositionMs: Long) {
        val now = System.currentTimeMillis()
        if (activePlaySegmentStartClockMs == null) {
            activePlaySegmentStartClockMs = now
        }
        val sid = activeSessionId ?: return
        val uid = activeVideoUid ?: return
        scope.launch(Dispatchers.IO) {
            logDao.insertEvent(
                PlaybackEventEntity(
                    sessionId = sid,
                    videoUid = uid,
                    eventType = "RESUMED",
                    clockTimestampMs = now,
                    videoPositionMs = videoPositionMs.coerceAtLeast(0L)
                )
            )
        }
    }

    fun onCompleted(durationMs: Long) {
        val now = System.currentTimeMillis()
        completedInSession = true
        val sid = activeSessionId ?: return
        val uid = activeVideoUid ?: return
        val safePos = durationMs.coerceAtLeast(0L)
        scope.launch(Dispatchers.IO) {
            logDao.insertEvent(
                PlaybackEventEntity(
                    sessionId = sid,
                    videoUid = uid,
                    eventType = "COMPLETED",
                    clockTimestampMs = now,
                    videoPositionMs = safePos
                )
            )
            videoDao.updatePlaybackPosition(uid, safePos, now)
        }
    }

    fun onSessionExited(exitPositionMs: Long) {
        val now = System.currentTimeMillis()
        val segStart = activePlaySegmentStartClockMs
        if (segStart != null) {
            accumulatedViewingTimeMs += (now - segStart).coerceAtLeast(0L)
            activePlaySegmentStartClockMs = null
        }
        val sid = activeSessionId ?: return
        val uid = activeVideoUid ?: return
        val safePos = exitPositionMs.coerceAtLeast(0L)
        val totalViewing = accumulatedViewingTimeMs
        val wasCompleted = completedInSession
        val titleSnapshot = activeVideoTitle
        val openedClock = openedAtClockMs
        val startPos = startedAtPositionMs

        activeSessionId = null
        activeVideoUid = null

        scope.launch(Dispatchers.IO) {
            logDao.updateSession(
                PlaybackSessionEntity(
                    sessionId = sid,
                    videoUid = uid,
                    videoTitleSnapshot = titleSnapshot,
                    openedAtClockMs = openedClock,
                    startedAtPositionMs = startPos,
                    exitedAtClockMs = now,
                    exitPositionMs = safePos,
                    totalViewingTimeMs = totalViewing,
                    completed = wasCompleted
                )
            )
            logDao.insertEvent(
                PlaybackEventEntity(
                    sessionId = sid,
                    videoUid = uid,
                    eventType = "EXITED",
                    clockTimestampMs = now,
                    videoPositionMs = safePos
                )
            )
            videoDao.updatePlaybackPosition(uid, safePos, now)
        }
    }
}
