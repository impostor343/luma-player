package com.lumaplayer.app

import android.app.Application
import com.lumaplayer.app.data.db.LumaDatabase
import com.lumaplayer.app.data.library.MediaLibraryScanner
import com.lumaplayer.app.data.library.VideoThumbnailLoader
import com.lumaplayer.app.data.prefs.PreferencesRepository

class LumaApplication : Application() {

    lateinit var database: LumaDatabase
        private set

    lateinit var preferences: PreferencesRepository
        private set

    lateinit var libraryScanner: MediaLibraryScanner
        private set

    lateinit var thumbnailLoader: VideoThumbnailLoader
        private set

    override fun onCreate() {
        super.onCreate()
        database = LumaDatabase.getInstance(this)
        preferences = PreferencesRepository(this)
        libraryScanner = MediaLibraryScanner(this, database.videoDao())
        thumbnailLoader = VideoThumbnailLoader(this)
    }
}
