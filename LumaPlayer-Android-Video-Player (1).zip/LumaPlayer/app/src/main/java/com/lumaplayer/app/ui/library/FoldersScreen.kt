package com.lumaplayer.app.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lumaplayer.app.data.db.VideoEntity
import com.lumaplayer.app.data.library.VideoThumbnailLoader
import com.lumaplayer.app.domain.FormatUtils
import com.lumaplayer.app.ui.components.VideoListRow
import com.lumaplayer.app.ui.components.VideoThumbnailBox

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(
    allVideos: List<VideoEntity>,
    selectedFolderPath: String?,
    thumbnailLoader: VideoThumbnailLoader,
    onSelectFolder: (String?) -> Unit,
    onAddSafFolder: () -> Unit,
    onPlayVideo: (VideoEntity) -> Unit,
    onOpenInfo: (VideoEntity) -> Unit
) {
    val available = remember(allVideos) { allVideos.filter { it.isAvailable } }
    val grouped = remember(available) {
        available.groupBy { it.folderPath }
            .entries
            .sortedBy { it.value.firstOrNull()?.folderName?.lowercase() ?: "" }
    }

    val selectedVideos = remember(available, selectedFolderPath) {
        if (selectedFolderPath == null) emptyList()
        else available.filter { it.folderPath == selectedFolderPath }.sortedBy { it.displayName.lowercase() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    val label = if (selectedFolderPath == null) {
                        "Folders"
                    } else {
                        selectedVideos.firstOrNull()?.folderName ?: selectedFolderPath.substringAfterLast('/')
                    }
                    Text(label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    if (selectedFolderPath != null) {
                        IconButton(onClick = { onSelectFolder(null) }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to folders")
                        }
                    }
                },
                actions = {
                    if (selectedFolderPath == null) {
                        IconButton(onClick = onAddSafFolder) {
                            Icon(Icons.Rounded.CreateNewFolder, contentDescription = "Add folder via SAF")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        if (selectedFolderPath == null) {
            if (grouped.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No video folders found yet.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(grouped, key = { it.key }) { (path, videos) ->
                        val first = videos.first()
                        val totalSize = videos.sumOf { it.sizeBytes }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectFolder(path) }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(96.dp)
                                        .aspectRatio(16f / 9f)
                                        .clip(RoundedCornerShape(8.dp))
                                ) {
                                    VideoThumbnailBox(
                                        uri = first.uri,
                                        isAvailable = first.isAvailable,
                                        thumbnailLoader = thumbnailLoader,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.Folder,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = first.folderName,
                                            style = MaterialTheme.typography.titleMedium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${videos.size} video${if (videos.size == 1) "" else "s"} • ${FormatUtils.formatFileSize(totalSize)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = path,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(selectedVideos, key = { it.uid }) { video ->
                    VideoListRow(
                        video = video,
                        thumbnailLoader = thumbnailLoader,
                        onPlayClick = { onPlayVideo(video) },
                        onInfoClick = { onOpenInfo(video) }
                    )
                }
            }
        }
    }
}
