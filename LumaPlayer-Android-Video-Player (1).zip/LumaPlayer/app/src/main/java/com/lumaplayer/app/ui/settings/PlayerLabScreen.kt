package com.lumaplayer.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lumaplayer.app.data.prefs.DecoderPreference
import com.lumaplayer.app.data.prefs.PlaybackProfile
import com.lumaplayer.app.data.prefs.PlayerLabConfig
import com.lumaplayer.app.data.prefs.PlayerLabMode
import com.lumaplayer.app.data.prefs.VideoDisplayMode
import com.lumaplayer.app.domain.PlayerLabValidator
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PlayerLabScreen(
    savedConfig: PlayerLabConfig,
    onSaveConfig: (PlayerLabConfig) -> Unit,
    onExportConfig: (PlayerLabConfig) -> Unit,
    onImportConfig: () -> Unit,
    onBack: () -> Unit
) {
    var draft by remember(savedConfig) { mutableStateOf(savedConfig) }
    val validation = remember(draft, savedConfig) { PlayerLabValidator.validate(draft, savedConfig) }
    val mode = runCatching { PlayerLabMode.valueOf(draft.mode) }.getOrDefault(PlayerLabMode.BASIC)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Player Lab", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "Configure AndroidX Media3 playback engine settings safely. Invalid combinations are blocked automatically.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (!validation.isValid) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Configuration Validation Error",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.SemiBold
                            )
                            validation.errors.forEach { err ->
                                Text(
                                    text = "• $err",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            } else if (validation.requiresPlaybackRestart) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Note: Changes to decoder or buffer settings take effect the next time a video is opened (playback restart required).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Mode Selector: Basic / Advanced / Expert
            item {
                LabSectionCard("Configuration Mode") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PlayerLabMode.entries.forEach { m ->
                            FilterChip(
                                selected = mode == m,
                                onClick = { draft = draft.copy(mode = m.name) },
                                label = { Text(m.label) }
                            )
                        }
                    }
                }
            }

            // Playback Profiles
            item {
                LabSectionCard("Playback Profiles") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        PlaybackProfile.entries.forEach { p ->
                            FilterChip(
                                selected = draft.profile == p.name,
                                onClick = { draft = PlayerLabValidator.applyProfilePreset(draft, p) },
                                label = { Text(p.label) }
                            )
                        }
                    }
                    val activeProfile = runCatching { PlaybackProfile.valueOf(draft.profile) }.getOrDefault(PlaybackProfile.BALANCED)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = activeProfile.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Decoder & Scaling (Basic+)
            item {
                LabSectionCard("Decoder & Video Scaling") {
                    Text("Decoder Preference", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DecoderPreference.entries.forEach { dec ->
                            FilterChip(
                                selected = draft.decoderPreference == dec.name,
                                onClick = { draft = draft.copy(decoderPreference = dec.name) },
                                label = { Text(dec.label) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Default Scaling Mode", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VideoDisplayMode.entries.forEach { dm ->
                            FilterChip(
                                selected = draft.defaultDisplayMode == dm.name,
                                onClick = { draft = draft.copy(defaultDisplayMode = dm.name) },
                                label = { Text(dm.label) }
                            )
                        }
                    }
                }
            }

            // HDR & Gestures (Basic+)
            item {
                LabSectionCard("HDR & Gesture Mappings") {
                    LabSwitchRow(
                        title = "HDR Strict Mode",
                        subtitle = "Preserve native HDR without silent SDR conversion.",
                        checked = draft.hdrStrictMode,
                        onCheckedChange = {
                            draft = draft.copy(
                                hdrStrictMode = it,
                                hdrCompatibilityToneMap = if (it) false else draft.hdrCompatibilityToneMap
                            )
                        }
                    )
                    LabSwitchRow(
                        title = "HDR Compatibility Tone-Mapping",
                        subtitle = "Explicitly tone-map HDR to SDR when display lacks native support.",
                        checked = draft.hdrCompatibilityToneMap,
                        onCheckedChange = {
                            draft = draft.copy(
                                hdrCompatibilityToneMap = it,
                                hdrStrictMode = if (it) false else draft.hdrStrictMode
                            )
                        }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Double-Tap Seek: ${draft.doubleTapSeekSec}s", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = draft.doubleTapSeekSec.toFloat(),
                        onValueChange = { draft = draft.copy(doubleTapSeekSec = it.roundToInt()) },
                        valueRange = 5f..30f
                    )
                    Text("Long-Press Temporary Speed: ${String.format("%.2fx", draft.longPressSpeed)}", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = draft.longPressSpeed,
                        onValueChange = {
                            val snapped = (it * 4f).roundToInt() / 4f
                            draft = draft.copy(longPressSpeed = snapped)
                        },
                        valueRange = 1.25f..3.0f
                    )
                }
            }

            // Advanced & Expert Buffer Tuning (Media3 DefaultLoadControl)
            if (mode == PlayerLabMode.ADVANCED || mode == PlayerLabMode.EXPERT) {
                item {
                    LabSectionCard("Media3 Buffer Configuration (Advanced)") {
                        Text("Minimum Buffer: ${draft.minBufferMs} ms", style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = draft.minBufferMs.toFloat(),
                            onValueChange = { draft = draft.copy(minBufferMs = (it / 1000f).roundToInt() * 1000) },
                            valueRange = 5_000f..60_000f
                        )
                        Text("Maximum Buffer: ${draft.maxBufferMs} ms", style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = draft.maxBufferMs.toFloat(),
                            onValueChange = { draft = draft.copy(maxBufferMs = (it / 1000f).roundToInt() * 1000) },
                            valueRange = 10_000f..180_000f
                        )
                        Text("Start Playback Buffer: ${draft.bufferForPlaybackMs} ms", style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = draft.bufferForPlaybackMs.toFloat(),
                            onValueChange = { draft = draft.copy(bufferForPlaybackMs = (it / 250f).roundToInt() * 250) },
                            valueRange = 250f..5_000f
                        )
                        Text("Rebuffer Threshold: ${draft.bufferForPlaybackAfterRebufferMs} ms", style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = draft.bufferForPlaybackAfterRebufferMs.toFloat(),
                            onValueChange = { draft = draft.copy(bufferForPlaybackAfterRebufferMs = (it / 500f).roundToInt() * 500) },
                            valueRange = 500f..10_000f
                        )
                    }
                }
            }

            // Expert Hardware Pipeline Flags
            if (mode == PlayerLabMode.EXPERT) {
                item {
                    LabSectionCard("Media3 Pipeline Flags (Expert)") {
                        LabSwitchRow(
                            title = "Asynchronous MediaCodec Queueing",
                            subtitle = "Improves frame pacing on Android 12+ hardware decoders.",
                            checked = draft.enableAsyncMediaCodecQueueing,
                            onCheckedChange = { draft = draft.copy(enableAsyncMediaCodecQueueing = it) }
                        )
                        LabSwitchRow(
                            title = "Audio Tunneling (When Supported)",
                            subtitle = "Offloads A/V sync to hardware audio DSP on supported decoders.",
                            checked = draft.enableAudioTunneling,
                            onCheckedChange = { draft = draft.copy(enableAudioTunneling = it) }
                        )
                    }
                }
            }

            // Action Buttons: Apply, Import/Export, Restore Defaults
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onSaveConfig(draft) },
                        enabled = validation.isValid,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Apply Configuration")
                    }
                    OutlinedButton(
                        onClick = {
                            val defaults = PlayerLabConfig()
                            draft = defaults
                            onSaveConfig(defaults)
                        }
                    ) {
                        Text("Restore Defaults")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { onExportConfig(draft) },
                        enabled = validation.isValid,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Export JSON")
                    }
                    OutlinedButton(
                        onClick = onImportConfig,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Import JSON")
                    }
                }
            }
        }
    }
}

@Composable
private fun LabSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun LabSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
