package com.lumaplayer.app.data.prefs

import kotlinx.serialization.Serializable

enum class VideoDisplayMode(val label: String) {
    FIT_TO_SCREEN("Fit to Screen"),
    FIT_WIDTH("Fit Width"),
    FIT_HEIGHT("Fit Height"),
    ORIGINAL_SIZE("Original Size"),
    CROP("Crop"),
    STRETCH("Stretch"),
    ZOOM("Zoom")
}

enum class DecoderPreference(val label: String) {
    HARDWARE_PREFERRED("Hardware (Recommended)"),
    HARDWARE_WITH_FALLBACK("Hardware + Software Fallback"),
    SOFTWARE_WHEN_AVAILABLE("Software (When Available)")
}

enum class OrientationMode(val label: String) {
    AUTO_SENSOR("Auto (Sensor)"),
    LANDSCAPE("Landscape"),
    PORTRAIT("Portrait"),
    VIDEO_MATCH("Match Video Aspect")
}

enum class AppThemeMode(val label: String) {
    SYSTEM("Follow System"),
    DARK("Dark"),
    LIGHT("Light")
}

enum class AccentPreset(val label: String, val argb: Long) {
    COBALT("Cobalt Blue", 0xFF4F9CF9),
    EMERALD("Emerald", 0xFF2CC48E),
    AMBER("Warm Amber", 0xFFF2A73B),
    CORAL("Coral Red", 0xFFE86452),
    VIOLET("Soft Violet", 0xFF9C7CF4)
}

enum class PlayerLabMode(val label: String) {
    BASIC("Basic"),
    ADVANCED("Advanced"),
    EXPERT("Expert")
}

enum class PlaybackProfile(val label: String, val description: String) {
    BALANCED("Balanced", "Smooth local playback with moderate memory footprint."),
    HIGH_BITRATE_HDR("High-Bitrate 4K / HDR", "Larger read-ahead buffer for high-bitrate HEVC/AV1 HDR files."),
    LOW_LATENCY_SEEK("Fast Seek", "Smaller playback buffer for snappy scrubbing."),
    BATTERY_SAVER("Battery Saver", "Hardware-only decoding with conservative buffering.")
}

enum class BrightnessBehavior(val label: String) {
    VIDEO_SURFACE_ONLY("Video Surface Only (Eye-Safe UI)"),
    HYBRID_CAPPED("Video Surface + Gentle Window Cap"),
    SYSTEM_DEFAULT("Follow System Brightness")
}

enum class HdrBrightnessBehavior(val label: String) {
    PRESERVE_HDR_HEADROOM("Preserve HDR Headroom (Separate from SDR)"),
    ALLOW_DIMMING_ONLY("Allow Dimming Only on HDR"),
    LOCK_HDR_DEFAULT("Keep System HDR Brightness")
}

enum class LibrarySortOrder(val label: String) {
    DATE_ADDED_DESC("Newest First"),
    NAME_ASC("Name (A-Z)"),
    DURATION_DESC("Longest First"),
    SIZE_DESC("Largest First"),
    RECENTLY_PLAYED("Recently Played")
}

@Serializable
data class PlayerLabConfig(
    val mode: String = PlayerLabMode.BASIC.name,
    val profile: String = PlaybackProfile.BALANCED.name,
    val decoderPreference: String = DecoderPreference.HARDWARE_WITH_FALLBACK.name,
    val minBufferMs: Int = 15_000,
    val maxBufferMs: Int = 50_000,
    val bufferForPlaybackMs: Int = 1_500,
    val bufferForPlaybackAfterRebufferMs: Int = 3_000,
    val enableAudioTunneling: Boolean = false,
    val enableAsyncMediaCodecQueueing: Boolean = true,
    val defaultDisplayMode: String = VideoDisplayMode.FIT_TO_SCREEN.name,
    val hdrStrictMode: Boolean = true,
    val hdrCompatibilityToneMap: Boolean = false,
    val doubleTapSeekSec: Int = 10,
    val longPressSpeed: Float = 2.0f,
    val customShortcutPlayPauseKey: String = "SPACE"
)

data class AppPreferences(
    // Playback
    val defaultPlaybackSpeed: Float = 1.0f,
    val resumeFromLastPosition: Boolean = true,
    val rememberPlaybackSpeed: Boolean = false,
    val autoNextVideo: Boolean = false,
    val loopCurrentVideo: Boolean = false,
    val backgroundPlayback: Boolean = false,
    val orientationMode: OrientationMode = OrientationMode.AUTO_SENSOR,
    val defaultDisplayMode: VideoDisplayMode = VideoDisplayMode.FIT_TO_SCREEN,
    val seekIntervalSec: Int = 10,
    val doubleTapSeekSec: Int = 10,
    val longPressSpeed: Float = 2.0f,
    val decoderPreference: DecoderPreference = DecoderPreference.HARDWARE_WITH_FALLBACK,
    val stopOnPlaybackError: Boolean = false,

    // HDR & Display
    val hdrDetectionEnabled: Boolean = true,
    val hdrStrictMode: Boolean = true,
    val hdrCompatibilityMode: Boolean = false,
    val showHdrIndicator: Boolean = true,
    val allowZoomBeyondCrop: Boolean = true,

    // Brightness & Eye Comfort
    val gestureBrightnessEnabled: Boolean = true,
    val brightnessSensitivity: Float = 1.0f,
    val rememberBrightness: Boolean = true,
    val savedVideoBrightness: Float = 0.75f, // 0.05f .. 1.0f
    val videoBrightnessBehavior: BrightnessBehavior = BrightnessBehavior.VIDEO_SURFACE_ONLY,
    val hdrBrightnessBehavior: HdrBrightnessBehavior = HdrBrightnessBehavior.PRESERVE_HDR_HEADROOM,
    val subtitleEyeComfortCompensation: Boolean = true,

    // Audio
    val preferredAudioLanguage: String = "System Default",
    val audioDelayMs: Long = 0L,
    val audioBoostPercent: Int = 0, // 0..60 safe LoudnessEnhancer range
    val audioPassthroughIfSupported: Boolean = false,

    // Subtitles
    val subtitleDelayMs: Long = 0L,
    val subtitleSizeSp: Float = 18f,
    val subtitleColorArgb: Long = 0xFFEBEBEB, // Neutral soft white (eye-safe)
    val subtitleOutlineEnabled: Boolean = true,
    val subtitleBackgroundAlpha: Float = 0.45f,
    val subtitleBottomPaddingFraction: Float = 0.08f,
    val preferredSubtitleLanguage: String = "System Default",

    // Gestures
    val gestureDoubleTapSeek: Boolean = true,
    val gestureHorizontalSeek: Boolean = true,
    val gestureVerticalVolume: Boolean = true,
    val gestureLongPressSpeed: Boolean = true,
    val gesturePinchZoom: Boolean = true,
    val gestureSensitivity: Float = 1.0f,

    // Library
    val gridViewEnabled: Boolean = true,
    val gridColumns: Int = 2,
    val showHiddenFolders: Boolean = false,
    val sortOrder: LibrarySortOrder = LibrarySortOrder.DATE_ADDED_DESC,
    val safFolderUris: Set<String> = emptySet(),
    val continueWatchingEnabled: Boolean = true,

    // Reviews & History
    val autoReviewPromptEnabled: Boolean = true,
    val reviewThresholdLongVideoMin: Int = 10, // > 60 min: final 10 min
    val reviewThresholdMediumVideoMin: Int = 2, // ~30 min: final 2 min
    val reviewThresholdShortVideoPercent: Int = 90,
    val historyRetentionDays: Int = 0, // 0 = Forever

    // Appearance
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val accentPreset: AccentPreset = AccentPreset.COBALT,
    val thumbnailScale: Float = 1.0f,
    val uiTextScale: Float = 1.0f,
    val animationsEnabled: Boolean = true,

    // Player Lab
    val playerLab: PlayerLabConfig = PlayerLabConfig()
)
