package com.lumaplayer.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.lumaplayer.app.data.prefs.AccentPreset
import com.lumaplayer.app.data.prefs.AppThemeMode

@Composable
fun LumaPlayerTheme(
    themeMode: AppThemeMode,
    accentPreset: AccentPreset,
    textScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val primary = Color(accentPreset.argb)
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = primary,
            onPrimary = Color(0xFF0A101D),
            primaryContainer = primary.copy(alpha = 0.20f),
            onPrimaryContainer = Color(0xFFE7F0FF),
            secondary = Color(0xFF94A3B8),
            onSecondary = Color(0xFF0F172A),
            background = Color(0xFF0B0E14),
            onBackground = Color(0xFFE6EAF2),
            surface = Color(0xFF111622),
            onSurface = Color(0xFFE6EAF2),
            surfaceVariant = Color(0xFF192030),
            onSurfaceVariant = Color(0xFFA0AEC0),
            outline = Color(0xFF2B3548),
            error = Color(0xFFF07167)
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = Color.White,
            primaryContainer = primary.copy(alpha = 0.14f),
            onPrimaryContainer = Color(0xFF10203A),
            secondary = Color(0xFF475569),
            onSecondary = Color.White,
            background = Color(0xFFF6F8FC),
            onBackground = Color(0xFF121826),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF121826),
            surfaceVariant = Color(0xFFEBEEF5),
            onSurfaceVariant = Color(0xFF4B5565),
            outline = Color(0xFFD0D7E3),
            error = Color(0xFFC93B32)
        )
    }

    val scale = textScale.coerceIn(0.85f, 1.3f)
    val typography = Typography(
        headlineSmall = TextStyle(fontSize = (22 * scale).sp, fontWeight = FontWeight.SemiBold, lineHeight = (28 * scale).sp),
        titleLarge = TextStyle(fontSize = (19 * scale).sp, fontWeight = FontWeight.SemiBold, lineHeight = (25 * scale).sp),
        titleMedium = TextStyle(fontSize = (16 * scale).sp, fontWeight = FontWeight.Medium, lineHeight = (22 * scale).sp),
        titleSmall = TextStyle(fontSize = (14 * scale).sp, fontWeight = FontWeight.Medium, lineHeight = (20 * scale).sp),
        bodyLarge = TextStyle(fontSize = (15 * scale).sp, fontWeight = FontWeight.Normal, lineHeight = (22 * scale).sp),
        bodyMedium = TextStyle(fontSize = (13.5f * scale).sp, fontWeight = FontWeight.Normal, lineHeight = (19 * scale).sp),
        bodySmall = TextStyle(fontSize = (12 * scale).sp, fontWeight = FontWeight.Normal, lineHeight = (16 * scale).sp),
        labelLarge = TextStyle(fontSize = (13.5f * scale).sp, fontWeight = FontWeight.Medium, lineHeight = (18 * scale).sp),
        labelMedium = TextStyle(fontSize = (11.5f * scale).sp, fontWeight = FontWeight.Medium, lineHeight = (15 * scale).sp),
        labelSmall = TextStyle(fontSize = (10.5f * scale).sp, fontWeight = FontWeight.Medium, lineHeight = (14 * scale).sp)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}
