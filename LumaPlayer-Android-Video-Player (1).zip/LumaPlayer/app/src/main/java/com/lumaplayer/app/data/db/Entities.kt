package com.lumaplayer.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "videos",
    indices = [
        Index(value = ["uri"], unique = true),
        Index(value = ["folderPath"]),
        Index(value = ["lastPlayedAtMs"]),
        Index(value = ["dateAddedSec"])
    ]
)
data class VideoEntity(
    @PrimaryKey val uid: String,
    val mediaStoreId: Long?,
    val uri: String,
    val displayName: String,
    val folderPath: String,
    val folderName: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val frameRate: Float,
    val videoCodec: String,
    val audioCodec: String,
    val bitDepth: Int,
    val hdrType: String, // SDR, HDR10, HDR10+, HLG, DOLBY_VISION
    val colorInfoText: String,
    val dateAddedSec: Long,
    val lastPositionMs: Long = 0L,
    val lastPlayedAtMs: Long = 0L,
    val isFavourite: Boolean = false,
    val isAvailable: Boolean = true,
    val reviewDismissed: Boolean = false
)

@Entity(
    tableName = "playback_sessions",
    indices = [Index(value = ["videoUid"]), Index(value = ["openedAtClockMs"])]
)
data class PlaybackSessionEntity(
    @PrimaryKey(autoGenerate = true) val sessionId: Long = 0L,
    val videoUid: String,
    val videoTitleSnapshot: String,
    val openedAtClockMs: Long,
    val startedAtPositionMs: Long,
    val exitedAtClockMs: Long = 0L,
    val exitPositionMs: Long = 0L,
    val totalViewingTimeMs: Long = 0L,
    val completed: Boolean = false
)

@Entity(
    tableName = "playback_events",
    foreignKeys = [
        ForeignKey(
            entity = PlaybackSessionEntity::class,
            parentColumns = ["sessionId"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["sessionId"]), Index(value = ["videoUid"])]
)
data class PlaybackEventEntity(
    @PrimaryKey(autoGenerate = true) val eventId: Long = 0L,
    val sessionId: Long,
    val videoUid: String,
    val eventType: String, // OPENED, PAUSED, RESUMED, COMPLETED, EXITED
    val clockTimestampMs: Long,
    val videoPositionMs: Long
)

@Entity(
    tableName = "review_folders",
    indices = [Index(value = ["name"], unique = true)]
)
data class ReviewFolderEntity(
    @PrimaryKey(autoGenerate = true) val folderId: Long = 0L,
    val name: String,
    val createdAtMs: Long
)

@Entity(
    tableName = "video_reviews",
    foreignKeys = [
        ForeignKey(
            entity = ReviewFolderEntity::class,
            parentColumns = ["folderId"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index(value = ["videoUid"]), Index(value = ["folderId"])]
)
data class VideoReviewEntity(
    @PrimaryKey(autoGenerate = true) val reviewId: Long = 0L,
    val videoUid: String,
    val videoTitleSnapshot: String,
    val rating: Int, // 1..5
    val writtenReview: String,
    val notes: String,
    val tags: String,
    val folderId: Long?,
    val dateWatchedMs: Long,
    val dateReviewedMs: Long
)
