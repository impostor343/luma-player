package com.lumaplayer.app.domain

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

object FormatUtils {

    fun formatResolutionBadge(width: Int, height: Int): String {
        val shortSide = min(width, height)
        val longSide = max(width, height)
        return when {
            shortSide <= 0 || longSide <= 0 -> "SD"
            shortSide >= 2160 || longSide >= 3840 -> "4K"
            shortSide >= 1440 || longSide >= 2560 -> "1440p"
            shortSide >= 1080 || longSide >= 1920 -> "1080p"
            shortSide >= 720 || longSide >= 1280 -> "720p"
            shortSide >= 480 -> "480p"
            else -> "${shortSide}p"
        }
    }

    fun formatDuration(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(safeMs)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatTimelineTimestamp(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(safeMs)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "Unknown"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
            else -> "$bytes B"
        }
    }

    fun formatAspectRatio(width: Int, height: Int): String {
        if (width <= 0 || height <= 0) return "Unknown"
        val g = gcd(width, height)
        val rw = width / g
        val rh = height / g
        val ratio = width.toFloat() / height.toFloat()
        return String.format(Locale.US, "%d:%d (%.2f:1)", rw, rh, ratio)
    }

    fun formatClockDateTime(epochMs: Long): String {
        if (epochMs <= 0L) return "—"
        val fmt = SimpleDateFormat("d MMMM, h:mm a", Locale.getDefault())
        return fmt.format(Date(epochMs))
    }

    fun formatClockTimeOnly(epochMs: Long): String {
        if (epochMs <= 0L) return "—"
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        return fmt.format(Date(epochMs))
    }

    fun formatDateOnly(epochMs: Long): String {
        if (epochMs <= 0L) return "—"
        val fmt = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
        return fmt.format(Date(epochMs))
    }

    private fun gcd(a: Int, b: Int): Int {
        var x = a
        var y = b
        while (y != 0) {
            val t = x % y
            x = y
            y = t
        }
        return if (x == 0) 1 else x
    }
}
