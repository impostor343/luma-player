package com.lumaplayer.app.domain

import android.content.Context
import android.hardware.display.DisplayManager
import android.media.MediaFormat
import android.os.Build
import android.view.Display
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi

enum class HdrFormat(val badgeLabel: String, val isHdr: Boolean) {
    SDR("SDR", false),
    HDR10("HDR10", true),
    HDR10_PLUS("HDR10+", true),
    HLG("HLG", true),
    DOLBY_VISION("DOLBY VISION", true);

    companion object {
        fun fromStored(value: String): HdrFormat =
            entries.firstOrNull { it.name == value || it.badgeLabel == value } ?: SDR
    }
}

enum class DisplayOutputMode(val label: String) {
    SDR_NATIVE("SDR Output"),
    HDR_DISPLAY_CAPABLE_UNVERIFIED("Display Supports HDR (Pipeline Output Unverified)"),
    HDR_ACTIVE_VERIFIED("HDR Output Active (Verified via Display HDR/SDR Ratio)"),
    HDR_TONE_MAPPED_TO_SDR("Tone-Mapped to SDR (Compatibility Mode)"),
    HDR_UNSUPPORTED_BY_DISPLAY("Display Does Not Report Support for This HDR Format")
}

data class HdrPlaybackReport(
    val sourceFormat: HdrFormat,
    val outputMode: DisplayOutputMode,
    val detailMessage: String,
    val colorTransferName: String,
    val colorStandardName: String,
    val bitDepth: Int
)

object HdrDetector {

    /**
     * Detects source HDR format strictly from actual Media3 Format metadata.
     * Never infers HDR from filename or resolution.
     */
    @OptIn(UnstableApi::class)
    fun detectFromMedia3Format(format: Format?): HdrFormat {
        if (format == null) return HdrFormat.SDR
        val mime = format.sampleMimeType.orEmpty()
        if (mime.equals(MimeTypes.VIDEO_DOLBY_VISION, ignoreCase = true)) {
            return HdrFormat.DOLBY_VISION
        }
        val colorInfo = format.colorInfo ?: return HdrFormat.SDR
        return when (colorInfo.colorTransfer) {
            C.COLOR_TRANSFER_HLG -> HdrFormat.HLG
            C.COLOR_TRANSFER_ST2084 -> {
                // HDR10+ uses ST.2084 PQ transfer with SMPTE 2094-40 dynamic metadata (or HEVC Main10 HDR10+ profile)
                val codecs = format.codecs.orEmpty().lowercase()
                val isHdr10PlusProfile = codecs.contains("hev1.2.4") ||
                    codecs.contains("hvc1.2.4") ||
                    codecs.contains("av01.0.09m.10") ||
                    codecs.contains("hdr10+")
                if (isHdr10PlusProfile) HdrFormat.HDR10_PLUS else HdrFormat.HDR10
            }
            else -> HdrFormat.SDR
        }
    }

    /**
     * Detects source HDR format from Android MediaMetadataRetriever color transfer & MIME values.
     */
    fun detectFromMetadataRetriever(
        colorTransfer: Int?,
        mimeType: String?,
        bitDepth: Int?
    ): HdrFormat {
        if (mimeType?.equals("video/dolby-vision", ignoreCase = true) == true) {
            return HdrFormat.DOLBY_VISION
        }
        return when (colorTransfer) {
            MediaFormat.COLOR_TRANSFER_HLG -> HdrFormat.HLG
            MediaFormat.COLOR_TRANSFER_ST2084 -> HdrFormat.HDR10
            else -> {
                // 10-bit alone without PQ/HLG transfer is still SDR (e.g., 10-bit SDR anime/camera)
                HdrFormat.SDR
            }
        }
    }

    fun queryDisplaySupportedHdrTypes(context: Context): Set<HdrFormat> {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY) ?: return emptySet()
        val caps = display.hdrCapabilities ?: return emptySet()
        val result = mutableSetOf<HdrFormat>()
        @Suppress("DEPRECATION")
        for (type in caps.supportedHdrTypes) {
            when (type) {
                Display.HdrCapabilities.HDR_TYPE_HDR10 -> result.add(HdrFormat.HDR10)
                Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS -> result.add(HdrFormat.HDR10_PLUS)
                Display.HdrCapabilities.HDR_TYPE_HLG -> result.add(HdrFormat.HLG)
                Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION -> result.add(HdrFormat.DOLBY_VISION)
            }
        }
        return result
    }

    fun evaluateOutputStatus(
        context: Context,
        sourceFormat: HdrFormat,
        hdrStrictMode: Boolean,
        hdrCompatibilityMode: Boolean,
        colorTransferName: String = "Standard",
        colorStandardName: String = "BT.709",
        bitDepth: Int = 8
    ): HdrPlaybackReport {
        if (!sourceFormat.isHdr) {
            return HdrPlaybackReport(
                sourceFormat = HdrFormat.SDR,
                outputMode = DisplayOutputMode.SDR_NATIVE,
                detailMessage = "Source is standard dynamic range (SDR).",
                colorTransferName = colorTransferName,
                colorStandardName = colorStandardName,
                bitDepth = bitDepth
            )
        }

        if (hdrCompatibilityMode && !hdrStrictMode) {
            return HdrPlaybackReport(
                sourceFormat = sourceFormat,
                outputMode = DisplayOutputMode.HDR_TONE_MAPPED_TO_SDR,
                detailMessage = "Compatibility mode enabled by user: HDR source is tone-mapped to SDR.",
                colorTransferName = colorTransferName,
                colorStandardName = colorStandardName,
                bitDepth = bitDepth
            )
        }

        val supported = queryDisplaySupportedHdrTypes(context)
        val displaySupportsSource = when (sourceFormat) {
            HdrFormat.HDR10_PLUS -> HdrFormat.HDR10_PLUS in supported || HdrFormat.HDR10 in supported
            else -> sourceFormat in supported
        }

        if (!displaySupportsSource) {
            val extra = if (sourceFormat == HdrFormat.DOLBY_VISION) {
                "This device's display does not advertise Dolby Vision support. Enable HDR Compatibility Mode if you want SDR fallback."
            } else {
                "This display does not report native ${sourceFormat.badgeLabel} support. HDR Strict Mode will not silently convert to SDR."
            }
            return HdrPlaybackReport(
                sourceFormat = sourceFormat,
                outputMode = DisplayOutputMode.HDR_UNSUPPORTED_BY_DISPLAY,
                detailMessage = extra,
                colorTransferName = colorTransferName,
                colorStandardName = colorStandardName,
                bitDepth = bitDepth
            )
        }

        // On Android 14+ (API 34+), check Display.getHdrSdrRatio() to verify active HDR headroom when exposed.
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && display != null) {
            if (display.isHdrSdrRatioAvailable && display.hdrSdrRatio > 1.05f) {
                return HdrPlaybackReport(
                    sourceFormat = sourceFormat,
                    outputMode = DisplayOutputMode.HDR_ACTIVE_VERIFIED,
                    detailMessage = "Display reports active HDR headroom (ratio ${String.format("%.2f", display.hdrSdrRatio)}x) for ${sourceFormat.badgeLabel}.",
                    colorTransferName = colorTransferName,
                    colorStandardName = colorStandardName,
                    bitDepth = bitDepth
                )
            }
        }

        return HdrPlaybackReport(
            sourceFormat = sourceFormat,
            outputMode = DisplayOutputMode.HDR_DISPLAY_CAPABLE_UNVERIFIED,
            detailMessage = "Source is ${sourceFormat.badgeLabel} and display reports support, but the playback pipeline does not expose live HDR output verification.",
            colorTransferName = colorTransferName,
            colorStandardName = colorStandardName,
            bitDepth = bitDepth
        )
    }
}
