package com.lumaplayer.app.ui.reviews

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lumaplayer.app.data.db.ReviewFolderEntity
import com.lumaplayer.app.data.db.VideoReviewEntity
import com.lumaplayer.app.domain.FormatUtils

private enum class ReviewSort(val label: String) {
    DATE_DESC("Newest Reviewed"),
    RATING_DESC("Highest Rating"),
    TITLE_ASC("Title (A-Z)")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewsScreen(
    reviews: List<VideoReviewEntity>,
    folders: List<ReviewFolderEntity>,
    availableVideoUids: Set<String>,
    onCreateFolder: (String) -> Unit,
    onRenameFolder: (Long, String) -> Unit,
    onDeleteFolder: (ReviewFolderEntity) -> Unit,
    onMoveReview: (Long, Long?) -> Unit,
    onUpdateReview: (VideoReviewEntity) -> Unit,
    onDeleteReview: (VideoReviewEntity) -> Unit
) {
    var selectedFolderId by remember { mutableStateOf<Long?>(-1L) } // -1L = All, null = Unfiled
    var searchQuery by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var sortBy by remember { mutableStateOf(ReviewSort.DATE_DESC) }
    var sortMenuOpen by remember { mutableStateOf(false) }

    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var folderToRename by remember { mutableStateOf<ReviewFolderEntity?>(null) }
    var reviewToMove by remember { mutableStateOf<VideoReviewEntity?>(null) }
    var reviewToEdit by remember { mutableStateOf<VideoReviewEntity?>(null) }

    val folderNames = remember(folders) { folders.associate { it.folderId to it.name } }

    val filtered = remember(reviews, selectedFolderId, searchQuery, sortBy) {
        val base = reviews.filter { r ->
            val matchesFolder = when (selectedFolderId) {
                -1L -> true
                null -> r.folderId == null
                else -> r.folderId == selectedFolderId
            }
            val matchesQuery = searchQuery.isBlank() ||
                r.videoTitleSnapshot.contains(searchQuery, ignoreCase = true) ||
                r.writtenReview.contains(searchQuery, ignoreCase = true) ||
                r.notes.contains(searchQuery, ignoreCase = true) ||
                r.tags.contains(searchQuery, ignoreCase = true)
            matchesFolder && matchesQuery
        }
        when (sortBy) {
            ReviewSort.DATE_DESC -> base.sortedByDescending { it.dateReviewedMs }
            ReviewSort.RATING_DESC -> base.sortedByDescending { it.rating }
            ReviewSort.TITLE_ASC -> base.sortedBy { it.videoTitleSnapshot.lowercase() }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (showSearch) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search reviews, notes, tags") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text("Reviews", fontWeight = FontWeight.SemiBold)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        showSearch = !showSearch
                        if (!showSearch) searchQuery = ""
                    }) {
                        Icon(Icons.Rounded.Search, contentDescription = "Search reviews")
                    }
                    Box {
                        IconButton(onClick = { sortMenuOpen = true }) {
                            Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = "Sort reviews")
                        }
                        DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                            ReviewSort.entries.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option.label) },
                                    onClick = {
                                        sortBy = option
                                        sortMenuOpen = false
                                    }
                                )
                            }
                        }
                    }
                    IconButton(onClick = { showCreateFolderDialog = true }) {
                        Icon(Icons.Rounded.CreateNewFolder, contentDescription = "New review folder")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Review Folders Bar
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedFolderId == -1L,
                        onClick = { selectedFolderId = -1L },
                        label = { Text("All (${reviews.size})") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFolderId == null,
                        onClick = { selectedFolderId = null },
                        label = { Text("Unfiled") }
                    )
                }
                items(folders, key = { it.folderId }) { folder ->
                    val count = reviews.count { it.folderId == folder.folderId }
                    FilterChip(
                        selected = selectedFolderId == folder.folderId,
                        onClick = { selectedFolderId = folder.folderId },
                        label = { Text("${folder.name} ($count)") },
                        trailingIcon = if (selectedFolderId == folder.folderId) {
                            {
                                Row {
                                    IconButton(
                                        onClick = { folderToRename = folder },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Rounded.Edit, contentDescription = "Rename folder", modifier = Modifier.size(14.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            selectedFolderId = -1L
                                            onDeleteFolder(folder)
                                        },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Delete folder", modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        } else null
                    )
                }
            }

            if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No reviews yet. Finish a video or open Video Info to add one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.reviewId }) { review ->
                        val videoAvailable = review.videoUid in availableVideoUids
                        val folderLabel = review.folderId?.let { folderNames[it] } ?: "Unfiled"
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = review.videoTitleSnapshot.substringBeforeLast('.'),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.Star,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = " ${review.rating}/5",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Folder: $folderLabel • Watched ${FormatUtils.formatDateOnly(review.dateWatchedMs)} • Reviewed ${FormatUtils.formatDateOnly(review.dateReviewedMs)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (!videoAvailable) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Original video is no longer available (review preserved independently)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }

                                if (review.writtenReview.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(text = review.writtenReview, style = MaterialTheme.typography.bodyMedium)
                                }
                                if (review.notes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Notes: ${review.notes}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (review.tags.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Tags: ${review.tags}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { reviewToMove = review }) {
                                        Icon(Icons.Rounded.DriveFileMove, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Text(" Move")
                                    }
                                    TextButton(onClick = { reviewToEdit = review }) {
                                        Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Text(" Edit")
                                    }
                                    TextButton(onClick = { onDeleteReview(review) }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Text(" Delete")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateFolderDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateFolderDialog = false },
            title = { Text("New Review Folder") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Folder name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    val trimmed = name.trim()
                    if (trimmed.isNotEmpty()) {
                        onCreateFolder(trimmed)
                        showCreateFolderDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateFolderDialog = false }) { Text("Cancel") }
            }
        )
    }

    folderToRename?.let { target ->
        var name by remember(target.folderId) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { folderToRename = null },
            title = { Text("Rename Folder") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("New name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    val trimmed = name.trim()
                    if (trimmed.isNotEmpty()) {
                        onRenameFolder(target.folderId, trimmed)
                        folderToRename = null
                    }
                }) { Text("Rename") }
            },
            dismissButton = {
                TextButton(onClick = { folderToRename = null }) { Text("Cancel") }
            }
        )
    }

    reviewToMove?.let { rev ->
        AlertDialog(
            onDismissRequest = { reviewToMove = null },
            title = { Text("Move Review to Folder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = {
                        onMoveReview(rev.reviewId, null)
                        reviewToMove = null
                    }) { Text("Unfiled") }
                    folders.forEach { f ->
                        TextButton(onClick = {
                            onMoveReview(rev.reviewId, f.folderId)
                            reviewToMove = null
                        }) { Text(f.name) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { reviewToMove = null }) { Text("Cancel") }
            }
        )
    }

    reviewToEdit?.let { rev ->
        ReviewPromptDialog(
            videoUid = rev.videoUid,
            videoTitle = rev.videoTitleSnapshot,
            dateWatchedMs = rev.dateWatchedMs,
            folders = folders,
            existingReview = rev,
            onCreateFolder = onCreateFolder,
            onSubmit = { updated ->
                onUpdateReview(updated)
                reviewToEdit = null
            },
            onDismiss = { reviewToEdit = null }
        )
    }
}
