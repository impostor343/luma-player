package com.lumaplayer.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.HdrOn
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.RateReview
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lumaplayer.app.data.prefs.AccentPreset
import com.lumaplayer.app.data.prefs.AppPreferences
import com.lumaplayer.app.data.prefs.AppThemeMode
import com.lumaplayer.app.data.prefs.BrightnessBehavior
import com.lumaplayer.app.data.prefs.DecoderPreference
import com.lumaplayer.app.data.prefs.HdrBrightnessBehavior
import com.lumaplayer.app.data.prefs.LibrarySortOrder
import com.lumaplayer.app.data.prefs.OrientationMode
import com.lumaplayer.app.data.prefs.VideoDisplayMode
import com.lumaplayer.app.domain.HdrDetector
import kotlin.math.roundToInt

enum class SettingsCategory(val title: String, val subtitle: String, val icon: ImageVector) {
    PLAYBACK("Playback", "Speed, resume, loop, decoder, orientation, seek", Icons.Rounded.PlayCircle),
    HDR_DISPLAY("HDR & Display", "HDR strict mode, detection, output verification, zoom", Icons.Rounded.HdrOn),
    BRIGHTNESS("Brightness & Eye Comfort", "Video-only brightness, HDR headroom, eye-safe subtitles", Icons.Rounded.Brightness6),
    AUDIO("Audio", "Preferred language, delay, safe loudness boost, passthrough", Icons.Rounded.GraphicEq),
    SUBTITLES("Subtitles", "Size, color, outline, background, position, delay", Icons.Rounded.Subtitles),
    GESTURES("Gestures", "Double-tap, horizontal seek, volume, long-press, pinch", Icons.Rounded.TouchApp),
    LIBRARY("Library", "Rescan, SAF folders, hidden folders, layout, sorting", Icons.Rounded.Folder),
    REVIEWS_HISTORY("Reviews & History", "Near-end thresholds, retention, backup export", Icons.Rounded.RateReview),
    APPEARANCE("Appearance", "Light/dark theme, accent color, density, text size", Icons.Rounded.Palette),
    PRIVACY("Privacy & Offline", "Zero internet permission, 100% local offline playback", Icons.Rounded.Shield),
    PLAYER_LAB("Player Lab", "Advanced Media3 engine configuration & profiles", Icons.Rounded.Science)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    prefs: AppPreferences,
    onUpdatePrefs: ((AppPreferences) -> AppPreferences) -> Unit,
    onResetBrightness: () -> Unit,
    onRescanLibrary: () -> Unit,
    onAddSafFolder: () -> Unit,
    onExportReviewsBackup: () -> Unit,
    onOpenPlayerLab: () -> Unit
) {
    var activeCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = activeCategory?.title ?: "Settings",
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    if (activeCategory != null) {
                        IconButton(onClick = { activeCategory = null }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to settings")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        if (activeCategory == null) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SettingsCategory.entries.forEach { category ->
                    item(key = category.name) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (category == SettingsCategory.PLAYER_LAB) {
                                        onOpenPlayerLab()
                                    } else {
                                        activeCategory = category
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = category.icon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(category.title, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        category.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (activeCategory) {
                    SettingsCategory.PLAYBACK -> {
                        item {
                            SettingsCard {
                                SettingSwitch(
                                    "Resume from last position",
                                    "Automatically continue where you left off.",
                                    prefs.resumeFromLastPosition
                                ) { v -> onUpdatePrefs { it.copy(resumeFromLastPosition = v) } }
                                SettingSwitch(
                                    "Remember playback speed",
                                    "Keep your last chosen speed for subsequent videos.",
                                    prefs.rememberPlaybackSpeed
                                ) { v -> onUpdatePrefs { it.copy(rememberPlaybackSpeed = v) } }
                                SettingSwitch(
                                    "Auto-play next video",
                                    "Advance to the next video in the same folder when finished.",
                                    prefs.autoNextVideo
                                ) { v -> onUpdatePrefs { it.copy(autoNextVideo = v) } }
                                SettingSwitch(
                                    "Loop current video",
                                    "Repeat the active video automatically.",
                                    prefs.loopCurrentVideo
                                ) { v -> onUpdatePrefs { it.copy(loopCurrentVideo = v) } }
                                SettingSwitch(
                                    "Background audio playback",
                                    "Keep audio playing if you switch away from LumaPlayer.",
                                    prefs.backgroundPlayback
                                ) { v -> onUpdatePrefs { it.copy(backgroundPlayback = v) } }
                                SettingSwitch(
                                    "Stop immediately on playback error",
                                    "Do not attempt automatic recovery when a stream errors.",
                                    prefs.stopOnPlaybackError
                                ) { v -> onUpdatePrefs { it.copy(stopOnPlaybackError = v) } }
                            }
                        }
                        item {
                            SettingsCard {
                                Text("Default Playback Speed: ${String.format("%.2fx", prefs.defaultPlaybackSpeed)}", style = MaterialTheme.typography.bodyLarge)
                                Slider(
                                    value = prefs.defaultPlaybackSpeed,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(defaultPlaybackSpeed = (v * 4f).roundToInt() / 4f) } },
                                    valueRange = 0.5f..2.0f
                                )
                                Text("Seek Interval: ${prefs.seekIntervalSec}s", style = MaterialTheme.typography.bodyLarge)
                                Slider(
                                    value = prefs.seekIntervalSec.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(seekIntervalSec = v.roundToInt()) } },
                                    valueRange = 5f..30f
                                )
                                Text("Double-Tap Seek: ${prefs.doubleTapSeekSec}s", style = MaterialTheme.typography.bodyLarge)
                                Slider(
                                    value = prefs.doubleTapSeekSec.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(doubleTapSeekSec = v.roundToInt()) } },
                                    valueRange = 5f..30f
                                )
                                Text("Long-Press Temporary Speed: ${String.format("%.2fx", prefs.longPressSpeed)}", style = MaterialTheme.typography.bodyLarge)
                                Slider(
                                    value = prefs.longPressSpeed,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(longPressSpeed = (v * 4f).roundToInt() / 4f) } },
                                    valueRange = 1.25f..3.0f
                                )
                            }
                        }
                        item {
                            SettingsCard {
                                Text("Screen Orientation", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OrientationMode.entries.forEach { m ->
                                        FilterChip(
                                            selected = prefs.orientationMode == m,
                                            onClick = { onUpdatePrefs { it.copy(orientationMode = m) } },
                                            label = { Text(m.label) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Default Aspect Ratio / Display Mode", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    VideoDisplayMode.entries.forEach { m ->
                                        FilterChip(
                                            selected = prefs.defaultDisplayMode == m,
                                            onClick = { onUpdatePrefs { it.copy(defaultDisplayMode = m) } },
                                            label = { Text(m.label) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Decoder Preference", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DecoderPreference.entries.forEach { d ->
                                        FilterChip(
                                            selected = prefs.decoderPreference == d,
                                            onClick = { onUpdatePrefs { it.copy(decoderPreference = d) } },
                                            label = { Text(d.label) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    SettingsCategory.HDR_DISPLAY -> {
                        val supported = HdrDetector.queryDisplaySupportedHdrTypes(context)
                        item {
                            SettingsCard {
                                Text("Device Display HDR Capabilities", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (supported.isEmpty()) {
                                        "Display reports SDR only."
                                    } else {
                                        "Display reports support for: ${supported.joinToString(", ") { it.badgeLabel }}"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "LumaPlayer distinguishes source metadata from verified display output and never fakes an HDR active badge.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        item {
                            SettingsCard {
                                SettingSwitch(
                                    "HDR metadata detection",
                                    "Inspect actual Media3 / MediaMetadataRetriever color transfer metadata.",
                                    prefs.hdrDetectionEnabled
                                ) { v -> onUpdatePrefs { it.copy(hdrDetectionEnabled = v) } }
                                SettingSwitch(
                                    "HDR Strict Mode (Default)",
                                    "Preserve native HDR output. Never silently convert HDR to SDR.",
                                    prefs.hdrStrictMode
                                ) { v ->
                                    onUpdatePrefs {
                                        it.copy(
                                            hdrStrictMode = v,
                                            hdrCompatibilityMode = if (v) false else it.hdrCompatibilityMode
                                        )
                                    }
                                }
                                SettingSwitch(
                                    "HDR Compatibility Mode (Tone-Map to SDR)",
                                    "Explicit opt-in only. Clearly marks playback as tone-mapped to SDR.",
                                    prefs.hdrCompatibilityMode
                                ) { v ->
                                    onUpdatePrefs {
                                        it.copy(
                                            hdrCompatibilityMode = v,
                                            hdrStrictMode = if (v) false else it.hdrStrictMode
                                        )
                                    }
                                }
                                SettingSwitch(
                                    "Show HDR / SDR indicator in player",
                                    "Keep format badge visible whenever player controls are visible.",
                                    prefs.showHdrIndicator
                                ) { v -> onUpdatePrefs { it.copy(showHdrIndicator = v) } }
                                SettingSwitch(
                                    "Allow pinch-zoom beyond crop",
                                    "Enable free zoom scaling up to 2.5x.",
                                    prefs.allowZoomBeyondCrop
                                ) { v -> onUpdatePrefs { it.copy(allowZoomBeyondCrop = v) } }
                            }
                        }
                    }

                    SettingsCategory.BRIGHTNESS -> {
                        item {
                            SettingsCard {
                                SettingSwitch(
                                    "Left-edge brightness gesture",
                                    "Swipe vertically on the left side of the video to adjust brightness.",
                                    prefs.gestureBrightnessEnabled
                                ) { v -> onUpdatePrefs { it.copy(gestureBrightnessEnabled = v) } }
                                SettingSwitch(
                                    "Remember video brightness",
                                    "Restore your preferred video brightness between sessions.",
                                    prefs.rememberBrightness
                                ) { v -> onUpdatePrefs { it.copy(rememberBrightness = v) } }
                                SettingSwitch(
                                    "Eye-comfort subtitle luminance",
                                    "Keep subtitles at normal, non-glaring brightness even at maximum video brightness or HDR.",
                                    prefs.subtitleEyeComfortCompensation
                                ) { v -> onUpdatePrefs { it.copy(subtitleEyeComfortCompensation = v) } }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Brightness Gesture Sensitivity: ${String.format("%.1fx", prefs.brightnessSensitivity)}", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.brightnessSensitivity,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(brightnessSensitivity = v) } },
                                    valueRange = 0.5f..2.0f
                                )
                                Text("Video Brightness Behavior", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    BrightnessBehavior.entries.forEach { b ->
                                        FilterChip(
                                            selected = prefs.videoBrightnessBehavior == b,
                                            onClick = { onUpdatePrefs { it.copy(videoBrightnessBehavior = b) } },
                                            label = { Text(b.label) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("HDR Brightness Behavior (Separate from SDR)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    HdrBrightnessBehavior.entries.forEach { hb ->
                                        FilterChip(
                                            selected = prefs.hdrBrightnessBehavior == hb,
                                            onClick = { onUpdatePrefs { it.copy(hdrBrightnessBehavior = hb) } },
                                            label = { Text(hb.label) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(onClick = onResetBrightness) {
                                    Text("Reset Brightness Preferences")
                                }
                            }
                        }
                    }

                    SettingsCategory.AUDIO -> {
                        item {
                            SettingsCard {
                                Text("Preferred Audio Language", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("System Default", "en", "hi", "ja", "es", "fr").forEach { lang ->
                                        FilterChip(
                                            selected = prefs.preferredAudioLanguage == lang,
                                            onClick = { onUpdatePrefs { it.copy(preferredAudioLanguage = lang) } },
                                            label = { Text(lang.uppercase()) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Audio Delay: ${prefs.audioDelayMs} ms", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.audioDelayMs.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(audioDelayMs = (v / 50f).roundToInt() * 50L) } },
                                    valueRange = -1000f..1000f
                                )
                                Text("Safe Volume Boost (LoudnessEnhancer): +${prefs.audioBoostPercent}%", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.audioBoostPercent.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(audioBoostPercent = v.roundToInt()) } },
                                    valueRange = 0f..60f
                                )
                                SettingSwitch(
                                    "Audio passthrough (when hardware supports)",
                                    "Uses platform offload/passthrough only when supported by the connected output.",
                                    prefs.audioPassthroughIfSupported
                                ) { v -> onUpdatePrefs { it.copy(audioPassthroughIfSupported = v) } }
                            }
                        }
                    }

                    SettingsCategory.SUBTITLES -> {
                        item {
                            SettingsCard {
                                Text("Subtitle Text Size: ${prefs.subtitleSizeSp.roundToInt()} sp", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.subtitleSizeSp,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(subtitleSizeSp = v.roundToInt().toFloat()) } },
                                    valueRange = 12f..30f
                                )
                                Text("Subtitle Background Opacity: ${(prefs.subtitleBackgroundAlpha * 100).roundToInt()}%", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.subtitleBackgroundAlpha,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(subtitleBackgroundAlpha = v) } },
                                    valueRange = 0f..0.85f
                                )
                                Text("Bottom Position Margin: ${(prefs.subtitleBottomPaddingFraction * 100).roundToInt()}%", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.subtitleBottomPaddingFraction,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(subtitleBottomPaddingFraction = v) } },
                                    valueRange = 0.03f..0.25f
                                )
                                Text("Subtitle Delay: ${prefs.subtitleDelayMs} ms", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.subtitleDelayMs.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(subtitleDelayMs = (v / 100f).roundToInt() * 100L) } },
                                    valueRange = -3000f..3000f
                                )
                                SettingSwitch(
                                    "Subtitle text outline",
                                    "Improves legibility on bright scenes without harsh glow.",
                                    prefs.subtitleOutlineEnabled
                                ) { v -> onUpdatePrefs { it.copy(subtitleOutlineEnabled = v) } }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Subtitle Base Color (Eye-Safe Presets)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(
                                        "Soft White" to 0xFFEBEBEB,
                                        "Warm Ivory" to 0xFFE8E2D0,
                                        "Soft Yellow" to 0xFFE5D27B,
                                        "Cool Gray" to 0xFFC8D0DC
                                    ).forEach { (label, argb) ->
                                        FilterChip(
                                            selected = prefs.subtitleColorArgb == argb,
                                            onClick = { onUpdatePrefs { it.copy(subtitleColorArgb = argb) } },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Supported external formats: SRT, WebVTT (.vtt), ASS/SSA, TTML, and embedded container tracks.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    SettingsCategory.GESTURES -> {
                        item {
                            SettingsCard {
                                SettingSwitch("Double-tap to seek", "Double-tap left/right edges to rewind or fast-forward.", prefs.gestureDoubleTapSeek) { v ->
                                    onUpdatePrefs { it.copy(gestureDoubleTapSeek = v) }
                                }
                                SettingSwitch("Horizontal swipe seek", "Drag horizontally across the video to scrub timeline.", prefs.gestureHorizontalSeek) { v ->
                                    onUpdatePrefs { it.copy(gestureHorizontalSeek = v) }
                                }
                                SettingSwitch("Left vertical brightness swipe", "Adjust video brightness on the left side.", prefs.gestureBrightnessEnabled) { v ->
                                    onUpdatePrefs { it.copy(gestureBrightnessEnabled = v) }
                                }
                                SettingSwitch("Right vertical volume swipe", "Adjust media volume on the right side.", prefs.gestureVerticalVolume) { v ->
                                    onUpdatePrefs { it.copy(gestureVerticalVolume = v) }
                                }
                                SettingSwitch("Long-press temporary 2x speed", "Hold screen for fast playback; always returns to prior speed on release.", prefs.gestureLongPressSpeed) { v ->
                                    onUpdatePrefs { it.copy(gestureLongPressSpeed = v) }
                                }
                                SettingSwitch("Pinch to zoom / scale", "Pinch video to zoom smoothly.", prefs.gesturePinchZoom) { v ->
                                    onUpdatePrefs { it.copy(gesturePinchZoom = v) }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Gesture Sensitivity: ${String.format("%.1fx", prefs.gestureSensitivity)}", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.gestureSensitivity,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(gestureSensitivity = v) } },
                                    valueRange = 0.5f..2.0f
                                )
                            }
                        }
                    }

                    SettingsCategory.LIBRARY -> {
                        item {
                            SettingsCard {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(onClick = onRescanLibrary) { Text("Rescan Videos") }
                                    OutlinedButton(onClick = onAddSafFolder) { Text("Add Folder (SAF)") }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                SettingSwitch("Show Continue Watching row", "Highlight partially watched videos on Home.", prefs.continueWatchingEnabled) { v ->
                                    onUpdatePrefs { it.copy(continueWatchingEnabled = v) }
                                }
                                SettingSwitch("Include hidden folders", "Scan folders starting with a dot (.).", prefs.showHiddenFolders) { v ->
                                    onUpdatePrefs { it.copy(showHiddenFolders = v) }
                                }
                                SettingSwitch("Grid layout", "Switch between 2/3-column grid and compact list.", prefs.gridViewEnabled) { v ->
                                    onUpdatePrefs { it.copy(gridViewEnabled = v) }
                                }
                                Text("Default Sort Order", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    LibrarySortOrder.entries.forEach { order ->
                                        FilterChip(
                                            selected = prefs.sortOrder == order,
                                            onClick = { onUpdatePrefs { it.copy(sortOrder = order) } },
                                            label = { Text(order.label) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    SettingsCategory.REVIEWS_HISTORY -> {
                        item {
                            SettingsCard {
                                SettingSwitch(
                                    "Automatic review prompt",
                                    "Prompt once when a video completes or exits near its ending.",
                                    prefs.autoReviewPromptEnabled
                                ) { v -> onUpdatePrefs { it.copy(autoReviewPromptEnabled = v) } }
                                Text("Videos > 60 min: prompt in final ${prefs.reviewThresholdLongVideoMin} min", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.reviewThresholdLongVideoMin.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(reviewThresholdLongVideoMin = v.roundToInt()) } },
                                    valueRange = 2f..20f
                                )
                                Text("Videos 20–60 min: prompt in final ${prefs.reviewThresholdMediumVideoMin} min", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.reviewThresholdMediumVideoMin.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(reviewThresholdMediumVideoMin = v.roundToInt()) } },
                                    valueRange = 1f..8f
                                )
                                Text("Videos < 20 min: prompt at ${prefs.reviewThresholdShortVideoPercent}% watched", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.reviewThresholdShortVideoPercent.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(reviewThresholdShortVideoPercent = v.roundToInt()) } },
                                    valueRange = 75f..98f
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(onClick = onExportReviewsBackup) {
                                    Text("Export Reviews & Folders Backup (JSON)")
                                }
                            }
                        }
                    }

                    SettingsCategory.APPEARANCE -> {
                        item {
                            SettingsCard {
                                Text("Theme Mode", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AppThemeMode.entries.forEach { tm ->
                                        FilterChip(
                                            selected = prefs.themeMode == tm,
                                            onClick = { onUpdatePrefs { it.copy(themeMode = tm) } },
                                            label = { Text(tm.label) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Accent Color", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AccentPreset.entries.forEach { ap ->
                                        FilterChip(
                                            selected = prefs.accentPreset == ap,
                                            onClick = { onUpdatePrefs { it.copy(accentPreset = ap) } },
                                            label = { Text(ap.label) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Grid Columns: ${prefs.gridColumns}", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.gridColumns.toFloat(),
                                    onValueChange = { v -> onUpdatePrefs { it.copy(gridColumns = v.roundToInt().coerceIn(2, 3)) } },
                                    valueRange = 2f..3f,
                                    steps = 0
                                )
                                Text("Interface Text Scale: ${(prefs.uiTextScale * 100).roundToInt()}%", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = prefs.uiTextScale,
                                    onValueChange = { v -> onUpdatePrefs { it.copy(uiTextScale = v) } },
                                    valueRange = 0.85f..1.25f
                                )
                                SettingSwitch("Smooth UI animations", "Enable subtle transitions across panels and player overlays.", prefs.animationsEnabled) { v ->
                                    onUpdatePrefs { it.copy(animationsEnabled = v) }
                                }
                            }
                        }
                    }

                    SettingsCategory.PRIVACY -> {
                        item {
                            SettingsCard {
                                Text("100% Offline Architecture", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "• No android.permission.INTERNET in manifest\n" +
                                        "• Zero advertisements, analytics, telemetry, or tracking SDKs\n" +
                                        "• No accounts, cloud uploads, or background data collection\n" +
                                        "• All playback logs, reviews, and settings stay strictly on your device",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    else -> Unit
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            content()
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
