package com.lumaplayer.app.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Query("SELECT * FROM videos ORDER BY dateAddedSec DESC")
    fun observeAllVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isAvailable = 1 ORDER BY dateAddedSec DESC")
    fun observeAvailableVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isAvailable = 1 AND lastPlayedAtMs > 0 ORDER BY lastPlayedAtMs DESC LIMIT 30")
    fun observeRecentlyPlayed(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isAvailable = 1 AND lastPositionMs > 5000 AND (durationMs = 0 OR lastPositionMs < durationMs - 5000) ORDER BY lastPlayedAtMs DESC LIMIT 20")
    fun observeContinueWatching(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isFavourite = 1 ORDER BY displayName ASC")
    fun observeFavourites(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE uid = :uid LIMIT 1")
    fun observeVideoByUid(uid: String): Flow<VideoEntity?>

    @Query("SELECT * FROM videos WHERE uid = :uid LIMIT 1")
    suspend fun getVideoByUid(uid: String): VideoEntity?

    @Query("SELECT * FROM videos WHERE uri = :uri LIMIT 1")
    suspend fun getVideoByUri(uri: String): VideoEntity?

    @Query("SELECT * FROM videos")
    suspend fun getAllVideosOnce(): List<VideoEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVideo(video: VideoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVideos(videos: List<VideoEntity>)

    @Query("UPDATE videos SET lastPositionMs = :positionMs, lastPlayedAtMs = :playedAtMs WHERE uid = :uid")
    suspend fun updatePlaybackPosition(uid: String, positionMs: Long, playedAtMs: Long)

    @Query("UPDATE videos SET isFavourite = :isFav WHERE uid = :uid")
    suspend fun setFavourite(uid: String, isFav: Boolean)

    @Query("UPDATE videos SET reviewDismissed = :dismissed WHERE uid = :uid")
    suspend fun setReviewDismissed(uid: String, dismissed: Boolean)

    @Query("UPDATE videos SET isAvailable = :available WHERE uid = :uid")
    suspend fun setAvailable(uid: String, available: Boolean)
}

@Dao
interface PlaybackLogDao {
    @Insert
    suspend fun insertSession(session: PlaybackSessionEntity): Long

    @Update
    suspend fun updateSession(session: PlaybackSessionEntity)

    @Insert
    suspend fun insertEvent(event: PlaybackEventEntity): Long

    @Query("SELECT * FROM playback_sessions WHERE videoUid = :videoUid ORDER BY openedAtClockMs DESC")
    fun observeSessionsForVideo(videoUid: String): Flow<List<PlaybackSessionEntity>>

    @Query("SELECT * FROM playback_sessions ORDER BY openedAtClockMs DESC LIMIT 200")
    fun observeAllSessions(): Flow<List<PlaybackSessionEntity>>

    @Query("SELECT * FROM playback_events WHERE sessionId = :sessionId ORDER BY clockTimestampMs ASC")
    fun observeEventsForSession(sessionId: Long): Flow<List<PlaybackEventEntity>>

    @Query("SELECT * FROM playback_events WHERE videoUid = :videoUid ORDER BY clockTimestampMs ASC")
    fun observeEventsForVideo(videoUid: String): Flow<List<PlaybackEventEntity>>

    @Query("SELECT * FROM playback_sessions WHERE sessionId = :sessionId LIMIT 1")
    suspend fun getSessionById(sessionId: Long): PlaybackSessionEntity?

    @Query("DELETE FROM playback_sessions WHERE openedAtClockMs < :cutoffMs")
    suspend fun pruneSessionsOlderThan(cutoffMs: Long)
}

@Dao
interface ReviewDao {
    @Query("SELECT * FROM review_folders ORDER BY name ASC")
    fun observeFolders(): Flow<List<ReviewFolderEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFolder(folder: ReviewFolderEntity): Long

    @Query("UPDATE review_folders SET name = :newName WHERE folderId = :folderId")
    suspend fun renameFolder(folderId: Long, newName: String)

    @Delete
    suspend fun deleteFolder(folder: ReviewFolderEntity)

    @Query("SELECT * FROM video_reviews ORDER BY dateReviewedMs DESC")
    fun observeAllReviews(): Flow<List<VideoReviewEntity>>

    @Query("SELECT * FROM video_reviews WHERE videoUid = :videoUid ORDER BY dateReviewedMs DESC")
    fun observeReviewsForVideo(videoUid: String): Flow<List<VideoReviewEntity>>

    @Query("SELECT COUNT(*) FROM video_reviews WHERE videoUid = :videoUid")
    suspend fun countReviewsForVideo(videoUid: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReview(review: VideoReviewEntity): Long

    @Query("UPDATE video_reviews SET folderId = :folderId WHERE reviewId = :reviewId")
    suspend fun moveReviewToFolder(reviewId: Long, folderId: Long?)

    @Delete
    suspend fun deleteReview(review: VideoReviewEntity)
}
