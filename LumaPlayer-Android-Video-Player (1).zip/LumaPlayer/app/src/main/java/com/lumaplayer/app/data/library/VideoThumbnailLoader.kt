package com.lumaplayer.app.data.library

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Memory-bounded real video thumbnail loader.
 * Never loads full-resolution frames into memory; caps cache to 1/8th of VM heap.
 */
class VideoThumbnailLoader(private val context: Context) {

    private val maxCacheKb = ((Runtime.getRuntime().maxMemory() / 1024L) / 8L).toInt().coerceAtLeast(4096)

    private val cache = object : LruCache<String, Bitmap>(maxCacheKb) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun getCached(uri: String): Bitmap? = cache.get(uri)

    suspend fun loadThumbnail(uriString: String, widthPx: Int = 360, heightPx: Int = 202): Bitmap? {
        cache.get(uriString)?.let { return it }
        return withContext(Dispatchers.IO) {
            val uri = Uri.parse(uriString)
            val bitmap = runCatching {
                context.contentResolver.loadThumbnail(uri, Size(widthPx, heightPx), null)
            }.getOrNull() ?: extractFrameFallback(uri, widthPx, heightPx)

            if (bitmap != null) {
                cache.put(uriString, bitmap)
            }
            bitmap
        }
    }

    fun clearCache() {
        cache.evictAll()
    }

    private fun extractFrameFallback(uri: Uri, targetW: Int, targetH: Int): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val raw = retriever.getScaledFrameAtTime(
                1_000_000L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                targetW,
                targetH
            ) ?: retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            raw
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }
}
