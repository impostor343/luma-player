package com.lumaplayer.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "lumaplayer_prefs")

class PreferencesRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
        encodeDefaults = true
    }

    private object Keys {
        val DEFAULT_SPEED = floatPreferencesKey("default_speed")
        val RESUME_LAST = booleanPreferencesKey("resume_last")
        val REMEMBER_SPEED = booleanPreferencesKey("remember_speed")
        val AUTO_NEXT = booleanPreferencesKey("auto_next")
        val LOOP_CURRENT = booleanPreferencesKey("loop_current")
        val BACKGROUND_PLAYBACK = booleanPreferencesKey("background_playback")
        val ORIENTATION_MODE = stringPreferencesKey("orientation_mode")
        val DISPLAY_MODE = stringPreferencesKey("display_mode")
        val SEEK_INTERVAL = intPreferencesKey("seek_interval")
        val DOUBLE_TAP_SEEK = intPreferencesKey("double_tap_seek")
        val LONG_PRESS_SPEED = floatPreferencesKey("long_press_speed")
        val DECODER_PREF = stringPreferencesKey("decoder_pref")
        val STOP_ON_ERROR = booleanPreferencesKey("stop_on_error")

        val HDR_DETECTION = booleanPreferencesKey("hdr_detection")
        val HDR_STRICT = booleanPreferencesKey("hdr_strict")
        val HDR_COMPAT = booleanPreferencesKey("hdr_compat")
        val SHOW_HDR_BADGE = booleanPreferencesKey("show_hdr_badge")
        val ALLOW_ZOOM = booleanPreferencesKey("allow_zoom")

        val GESTURE_BRIGHTNESS = booleanPreferencesKey("gesture_brightness")
        val BRIGHTNESS_SENSITIVITY = floatPreferencesKey("brightness_sensitivity")
        val REMEMBER_BRIGHTNESS = booleanPreferencesKey("remember_brightness")
        val SAVED_BRIGHTNESS = floatPreferencesKey("saved_brightness")
        val BRIGHTNESS_BEHAVIOR = stringPreferencesKey("brightness_behavior")
        val HDR_BRIGHTNESS_BEHAVIOR = stringPreferencesKey("hdr_brightness_behavior")
        val SUBTITLE_EYE_COMFORT = booleanPreferencesKey("subtitle_eye_comfort")

        val PREF_AUDIO_LANG = stringPreferencesKey("pref_audio_lang")
        val AUDIO_DELAY = longPreferencesKey("audio_delay")
        val AUDIO_BOOST = intPreferencesKey("audio_boost")
        val AUDIO_PASSTHROUGH = booleanPreferencesKey("audio_passthrough")

        val SUBTITLE_DELAY = longPreferencesKey("subtitle_delay")
        val SUBTITLE_SIZE = floatPreferencesKey("subtitle_size")
        val SUBTITLE_COLOR = longPreferencesKey("subtitle_color")
        val SUBTITLE_OUTLINE = booleanPreferencesKey("subtitle_outline")
        val SUBTITLE_BG_ALPHA = floatPreferencesKey("subtitle_bg_alpha")
        val SUBTITLE_POS = floatPreferencesKey("subtitle_pos")
        val PREF_SUBTITLE_LANG = stringPreferencesKey("pref_subtitle_lang")

        val GESTURE_DOUBLE_TAP = booleanPreferencesKey("gesture_double_tap")
        val GESTURE_H_SEEK = booleanPreferencesKey("gesture_h_seek")
        val GESTURE_V_VOLUME = booleanPreferencesKey("gesture_v_volume")
        val GESTURE_LONG_PRESS = booleanPreferencesKey("gesture_long_press")
        val GESTURE_PINCH = booleanPreferencesKey("gesture_pinch")
        val GESTURE_SENSITIVITY = floatPreferencesKey("gesture_sensitivity")

        val GRID_VIEW = booleanPreferencesKey("grid_view")
        val GRID_COLUMNS = intPreferencesKey("grid_columns")
        val SHOW_HIDDEN_FOLDERS = booleanPreferencesKey("show_hidden_folders")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val SAF_FOLDERS = stringSetPreferencesKey("saf_folders")
        val CONTINUE_WATCHING = booleanPreferencesKey("continue_watching")

        val AUTO_REVIEW = booleanPreferencesKey("auto_review")
        val REVIEW_LONG_MIN = intPreferencesKey("review_long_min")
        val REVIEW_MED_MIN = intPreferencesKey("review_med_min")
        val REVIEW_SHORT_PCT = intPreferencesKey("review_short_pct")
        val HISTORY_RETENTION = intPreferencesKey("history_retention")

        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_PRESET = stringPreferencesKey("accent_preset")
        val THUMB_SCALE = floatPreferencesKey("thumb_scale")
        val TEXT_SCALE = floatPreferencesKey("text_scale")
        val ANIMATIONS = booleanPreferencesKey("animations")

        val PLAYER_LAB_JSON = stringPreferencesKey("player_lab_json")
    }

    val preferencesFlow: Flow<AppPreferences> = context.dataStore.data.map { p ->
        val lab = p[Keys.PLAYER_LAB_JSON]?.let { raw ->
            runCatching { json.decodeFromString<PlayerLabConfig>(raw) }.getOrNull()
        } ?: PlayerLabConfig()

        AppPreferences(
            defaultPlaybackSpeed = p[Keys.DEFAULT_SPEED] ?: 1.0f,
            resumeFromLastPosition = p[Keys.RESUME_LAST] ?: true,
            rememberPlaybackSpeed = p[Keys.REMEMBER_SPEED] ?: false,
            autoNextVideo = p[Keys.AUTO_NEXT] ?: false,
            loopCurrentVideo = p[Keys.LOOP_CURRENT] ?: false,
            backgroundPlayback = p[Keys.BACKGROUND_PLAYBACK] ?: false,
            orientationMode = enumOrDefault(p[Keys.ORIENTATION_MODE], OrientationMode.AUTO_SENSOR),
            defaultDisplayMode = enumOrDefault(p[Keys.DISPLAY_MODE], VideoDisplayMode.FIT_TO_SCREEN),
            seekIntervalSec = p[Keys.SEEK_INTERVAL] ?: 10,
            doubleTapSeekSec = p[Keys.DOUBLE_TAP_SEEK] ?: 10,
            longPressSpeed = p[Keys.LONG_PRESS_SPEED] ?: 2.0f,
            decoderPreference = enumOrDefault(p[Keys.DECODER_PREF], DecoderPreference.HARDWARE_WITH_FALLBACK),
            stopOnPlaybackError = p[Keys.STOP_ON_ERROR] ?: false,

            hdrDetectionEnabled = p[Keys.HDR_DETECTION] ?: true,
            hdrStrictMode = p[Keys.HDR_STRICT] ?: true,
            hdrCompatibilityMode = p[Keys.HDR_COMPAT] ?: false,
            showHdrIndicator = p[Keys.SHOW_HDR_BADGE] ?: true,
            allowZoomBeyondCrop = p[Keys.ALLOW_ZOOM] ?: true,

            gestureBrightnessEnabled = p[Keys.GESTURE_BRIGHTNESS] ?: true,
            brightnessSensitivity = p[Keys.BRIGHTNESS_SENSITIVITY] ?: 1.0f,
            rememberBrightness = p[Keys.REMEMBER_BRIGHTNESS] ?: true,
            savedVideoBrightness = p[Keys.SAVED_BRIGHTNESS] ?: 0.75f,
            videoBrightnessBehavior = enumOrDefault(p[Keys.BRIGHTNESS_BEHAVIOR], BrightnessBehavior.VIDEO_SURFACE_ONLY),
            hdrBrightnessBehavior = enumOrDefault(p[Keys.HDR_BRIGHTNESS_BEHAVIOR], HdrBrightnessBehavior.PRESERVE_HDR_HEADROOM),
            subtitleEyeComfortCompensation = p[Keys.SUBTITLE_EYE_COMFORT] ?: true,

            preferredAudioLanguage = p[Keys.PREF_AUDIO_LANG] ?: "System Default",
            audioDelayMs = p[Keys.AUDIO_DELAY] ?: 0L,
            audioBoostPercent = p[Keys.AUDIO_BOOST] ?: 0,
            audioPassthroughIfSupported = p[Keys.AUDIO_PASSTHROUGH] ?: false,

            subtitleDelayMs = p[Keys.SUBTITLE_DELAY] ?: 0L,
            subtitleSizeSp = p[Keys.SUBTITLE_SIZE] ?: 18f,
            subtitleColorArgb = p[Keys.SUBTITLE_COLOR] ?: 0xFFEBEBEB,
            subtitleOutlineEnabled = p[Keys.SUBTITLE_OUTLINE] ?: true,
            subtitleBackgroundAlpha = p[Keys.SUBTITLE_BG_ALPHA] ?: 0.45f,
            subtitleBottomPaddingFraction = p[Keys.SUBTITLE_POS] ?: 0.08f,
            preferredSubtitleLanguage = p[Keys.PREF_SUBTITLE_LANG] ?: "System Default",

            gestureDoubleTapSeek = p[Keys.GESTURE_DOUBLE_TAP] ?: true,
            gestureHorizontalSeek = p[Keys.GESTURE_H_SEEK] ?: true,
            gestureVerticalVolume = p[Keys.GESTURE_V_VOLUME] ?: true,
            gestureLongPressSpeed = p[Keys.GESTURE_LONG_PRESS] ?: true,
            gesturePinchZoom = p[Keys.GESTURE_PINCH] ?: true,
            gestureSensitivity = p[Keys.GESTURE_SENSITIVITY] ?: 1.0f,

            gridViewEnabled = p[Keys.GRID_VIEW] ?: true,
            gridColumns = p[Keys.GRID_COLUMNS] ?: 2,
            showHiddenFolders = p[Keys.SHOW_HIDDEN_FOLDERS] ?: false,
            sortOrder = enumOrDefault(p[Keys.SORT_ORDER], LibrarySortOrder.DATE_ADDED_DESC),
            safFolderUris = p[Keys.SAF_FOLDERS] ?: emptySet(),
            continueWatchingEnabled = p[Keys.CONTINUE_WATCHING] ?: true,

            autoReviewPromptEnabled = p[Keys.AUTO_REVIEW] ?: true,
            reviewThresholdLongVideoMin = p[Keys.REVIEW_LONG_MIN] ?: 10,
            reviewThresholdMediumVideoMin = p[Keys.REVIEW_MED_MIN] ?: 2,
            reviewThresholdShortVideoPercent = p[Keys.REVIEW_SHORT_PCT] ?: 90,
            historyRetentionDays = p[Keys.HISTORY_RETENTION] ?: 0,

            themeMode = enumOrDefault(p[Keys.THEME_MODE], AppThemeMode.DARK),
            accentPreset = enumOrDefault(p[Keys.ACCENT_PRESET], AccentPreset.COBALT),
            thumbnailScale = p[Keys.THUMB_SCALE] ?: 1.0f,
            uiTextScale = p[Keys.TEXT_SCALE] ?: 1.0f,
            animationsEnabled = p[Keys.ANIMATIONS] ?: true,
            playerLab = lab
        )
    }

    suspend fun update(transform: (AppPreferences) -> AppPreferences) {
        context.dataStore.edit { p ->
            val current = AppPreferences(
                defaultPlaybackSpeed = p[Keys.DEFAULT_SPEED] ?: 1.0f,
                resumeFromLastPosition = p[Keys.RESUME_LAST] ?: true,
                rememberPlaybackSpeed = p[Keys.REMEMBER_SPEED] ?: false,
                autoNextVideo = p[Keys.AUTO_NEXT] ?: false,
                loopCurrentVideo = p[Keys.LOOP_CURRENT] ?: false,
                backgroundPlayback = p[Keys.BACKGROUND_PLAYBACK] ?: false,
                orientationMode = enumOrDefault(p[Keys.ORIENTATION_MODE], OrientationMode.AUTO_SENSOR),
                defaultDisplayMode = enumOrDefault(p[Keys.DISPLAY_MODE], VideoDisplayMode.FIT_TO_SCREEN),
                seekIntervalSec = p[Keys.SEEK_INTERVAL] ?: 10,
                doubleTapSeekSec = p[Keys.DOUBLE_TAP_SEEK] ?: 10,
                longPressSpeed = p[Keys.LONG_PRESS_SPEED] ?: 2.0f,
                decoderPreference = enumOrDefault(p[Keys.DECODER_PREF], DecoderPreference.HARDWARE_WITH_FALLBACK),
                stopOnPlaybackError = p[Keys.STOP_ON_ERROR] ?: false,
                hdrDetectionEnabled = p[Keys.HDR_DETECTION] ?: true,
                hdrStrictMode = p[Keys.HDR_STRICT] ?: true,
                hdrCompatibilityMode = p[Keys.HDR_COMPAT] ?: false,
                showHdrIndicator = p[Keys.SHOW_HDR_BADGE] ?: true,
                allowZoomBeyondCrop = p[Keys.ALLOW_ZOOM] ?: true,
                gestureBrightnessEnabled = p[Keys.GESTURE_BRIGHTNESS] ?: true,
                brightnessSensitivity = p[Keys.BRIGHTNESS_SENSITIVITY] ?: 1.0f,
                rememberBrightness = p[Keys.REMEMBER_BRIGHTNESS] ?: true,
                savedVideoBrightness = p[Keys.SAVED_BRIGHTNESS] ?: 0.75f,
                videoBrightnessBehavior = enumOrDefault(p[Keys.BRIGHTNESS_BEHAVIOR], BrightnessBehavior.VIDEO_SURFACE_ONLY),
                hdrBrightnessBehavior = enumOrDefault(p[Keys.HDR_BRIGHTNESS_BEHAVIOR], HdrBrightnessBehavior.PRESERVE_HDR_HEADROOM),
                subtitleEyeComfortCompensation = p[Keys.SUBTITLE_EYE_COMFORT] ?: true,
                preferredAudioLanguage = p[Keys.PREF_AUDIO_LANG] ?: "System Default",
                audioDelayMs = p[Keys.AUDIO_DELAY] ?: 0L,
                audioBoostPercent = p[Keys.AUDIO_BOOST] ?: 0,
                audioPassthroughIfSupported = p[Keys.AUDIO_PASSTHROUGH] ?: false,
                subtitleDelayMs = p[Keys.SUBTITLE_DELAY] ?: 0L,
                subtitleSizeSp = p[Keys.SUBTITLE_SIZE] ?: 18f,
                subtitleColorArgb = p[Keys.SUBTITLE_COLOR] ?: 0xFFEBEBEB,
                subtitleOutlineEnabled = p[Keys.SUBTITLE_OUTLINE] ?: true,
                subtitleBackgroundAlpha = p[Keys.SUBTITLE_BG_ALPHA] ?: 0.45f,
                subtitleBottomPaddingFraction = p[Keys.SUBTITLE_POS] ?: 0.08f,
                preferredSubtitleLanguage = p[Keys.PREF_SUBTITLE_LANG] ?: "System Default",
                gestureDoubleTapSeek = p[Keys.GESTURE_DOUBLE_TAP] ?: true,
                gestureHorizontalSeek = p[Keys.GESTURE_H_SEEK] ?: true,
                gestureVerticalVolume = p[Keys.GESTURE_V_VOLUME] ?: true,
                gestureLongPressSpeed = p[Keys.GESTURE_LONG_PRESS] ?: true,
                gesturePinchZoom = p[Keys.GESTURE_PINCH] ?: true,
                gestureSensitivity = p[Keys.GESTURE_SENSITIVITY] ?: 1.0f,
                gridViewEnabled = p[Keys.GRID_VIEW] ?: true,
                gridColumns = p[Keys.GRID_COLUMNS] ?: 2,
                showHiddenFolders = p[Keys.SHOW_HIDDEN_FOLDERS] ?: false,
                sortOrder = enumOrDefault(p[Keys.SORT_ORDER], LibrarySortOrder.DATE_ADDED_DESC),
                safFolderUris = p[Keys.SAF_FOLDERS] ?: emptySet(),
                continueWatchingEnabled = p[Keys.CONTINUE_WATCHING] ?: true,
                autoReviewPromptEnabled = p[Keys.AUTO_REVIEW] ?: true,
                reviewThresholdLongVideoMin = p[Keys.REVIEW_LONG_MIN] ?: 10,
                reviewThresholdMediumVideoMin = p[Keys.REVIEW_MED_MIN] ?: 2,
                reviewThresholdShortVideoPercent = p[Keys.REVIEW_SHORT_PCT] ?: 90,
                historyRetentionDays = p[Keys.HISTORY_RETENTION] ?: 0,
                themeMode = enumOrDefault(p[Keys.THEME_MODE], AppThemeMode.DARK),
                accentPreset = enumOrDefault(p[Keys.ACCENT_PRESET], AccentPreset.COBALT),
                thumbnailScale = p[Keys.THUMB_SCALE] ?: 1.0f,
                uiTextScale = p[Keys.TEXT_SCALE] ?: 1.0f,
                animationsEnabled = p[Keys.ANIMATIONS] ?: true,
                playerLab = p[Keys.PLAYER_LAB_JSON]?.let { raw ->
                    runCatching { json.decodeFromString<PlayerLabConfig>(raw) }.getOrNull()
                } ?: PlayerLabConfig()
            )
            val updated = transform(current)
            p[Keys.DEFAULT_SPEED] = updated.defaultPlaybackSpeed
            p[Keys.RESUME_LAST] = updated.resumeFromLastPosition
            p[Keys.REMEMBER_SPEED] = updated.rememberPlaybackSpeed
            p[Keys.AUTO_NEXT] = updated.autoNextVideo
            p[Keys.LOOP_CURRENT] = updated.loopCurrentVideo
            p[Keys.BACKGROUND_PLAYBACK] = updated.backgroundPlayback
            p[Keys.ORIENTATION_MODE] = updated.orientationMode.name
            p[Keys.DISPLAY_MODE] = updated.defaultDisplayMode.name
            p[Keys.SEEK_INTERVAL] = updated.seekIntervalSec
            p[Keys.DOUBLE_TAP_SEEK] = updated.doubleTapSeekSec
            p[Keys.LONG_PRESS_SPEED] = updated.longPressSpeed
            p[Keys.DECODER_PREF] = updated.decoderPreference.name
            p[Keys.STOP_ON_ERROR] = updated.stopOnPlaybackError

            p[Keys.HDR_DETECTION] = updated.hdrDetectionEnabled
            p[Keys.HDR_STRICT] = updated.hdrStrictMode
            p[Keys.HDR_COMPAT] = updated.hdrCompatibilityMode
            p[Keys.SHOW_HDR_BADGE] = updated.showHdrIndicator
            p[Keys.ALLOW_ZOOM] = updated.allowZoomBeyondCrop

            p[Keys.GESTURE_BRIGHTNESS] = updated.gestureBrightnessEnabled
            p[Keys.BRIGHTNESS_SENSITIVITY] = updated.brightnessSensitivity
            p[Keys.REMEMBER_BRIGHTNESS] = updated.rememberBrightness
            p[Keys.SAVED_BRIGHTNESS] = updated.savedVideoBrightness
            p[Keys.BRIGHTNESS_BEHAVIOR] = updated.videoBrightnessBehavior.name
            p[Keys.HDR_BRIGHTNESS_BEHAVIOR] = updated.hdrBrightnessBehavior.name
            p[Keys.SUBTITLE_EYE_COMFORT] = updated.subtitleEyeComfortCompensation

            p[Keys.PREF_AUDIO_LANG] = updated.preferredAudioLanguage
            p[Keys.AUDIO_DELAY] = updated.audioDelayMs
            p[Keys.AUDIO_BOOST] = updated.audioBoostPercent
            p[Keys.AUDIO_PASSTHROUGH] = updated.audioPassthroughIfSupported

            p[Keys.SUBTITLE_DELAY] = updated.subtitleDelayMs
            p[Keys.SUBTITLE_SIZE] = updated.subtitleSizeSp
            p[Keys.SUBTITLE_COLOR] = updated.subtitleColorArgb
            p[Keys.SUBTITLE_OUTLINE] = updated.subtitleOutlineEnabled
            p[Keys.SUBTITLE_BG_ALPHA] = updated.subtitleBackgroundAlpha
            p[Keys.SUBTITLE_POS] = updated.subtitleBottomPaddingFraction
            p[Keys.PREF_SUBTITLE_LANG] = updated.preferredSubtitleLanguage

            p[Keys.GESTURE_DOUBLE_TAP] = updated.gestureDoubleTapSeek
            p[Keys.GESTURE_H_SEEK] = updated.gestureHorizontalSeek
            p[Keys.GESTURE_V_VOLUME] = updated.gestureVerticalVolume
            p[Keys.GESTURE_LONG_PRESS] = updated.gestureLongPressSpeed
            p[Keys.GESTURE_PINCH] = updated.gesturePinchZoom
            p[Keys.GESTURE_SENSITIVITY] = updated.gestureSensitivity

            p[Keys.GRID_VIEW] = updated.gridViewEnabled
            p[Keys.GRID_COLUMNS] = updated.gridColumns
            p[Keys.SHOW_HIDDEN_FOLDERS] = updated.showHiddenFolders
            p[Keys.SORT_ORDER] = updated.sortOrder.name
            p[Keys.SAF_FOLDERS] = updated.safFolderUris
            p[Keys.CONTINUE_WATCHING] = updated.continueWatchingEnabled

            p[Keys.AUTO_REVIEW] = updated.autoReviewPromptEnabled
            p[Keys.REVIEW_LONG_MIN] = updated.reviewThresholdLongVideoMin
            p[Keys.REVIEW_MED_MIN] = updated.reviewThresholdMediumVideoMin
            p[Keys.REVIEW_SHORT_PCT] = updated.reviewThresholdShortVideoPercent
            p[Keys.HISTORY_RETENTION] = updated.historyRetentionDays

            p[Keys.THEME_MODE] = updated.themeMode.name
            p[Keys.ACCENT_PRESET] = updated.accentPreset.name
            p[Keys.THUMB_SCALE] = updated.thumbnailScale
            p[Keys.TEXT_SCALE] = updated.uiTextScale
            p[Keys.ANIMATIONS] = updated.animationsEnabled

            p[Keys.PLAYER_LAB_JSON] = json.encodeToString(updated.playerLab)
        }
    }

    suspend fun resetBrightnessPreferences() {
        update {
            it.copy(
                gestureBrightnessEnabled = true,
                brightnessSensitivity = 1.0f,
                rememberBrightness = true,
                savedVideoBrightness = 0.75f,
                videoBrightnessBehavior = BrightnessBehavior.VIDEO_SURFACE_ONLY,
                hdrBrightnessBehavior = HdrBrightnessBehavior.PRESERVE_HDR_HEADROOM,
                subtitleEyeComfortCompensation = true
            )
        }
    }

    fun exportPlayerLabJson(config: PlayerLabConfig): String = json.encodeToString(config)

    fun parsePlayerLabJson(raw: String): Result<PlayerLabConfig> =
        runCatching { json.decodeFromString<PlayerLabConfig>(raw) }

    private inline fun <reified T : Enum<T>> enumOrDefault(value: String?, default: T): T {
        if (value == null) return default
        return runCatching { enumValueOf<T>(value) }.getOrDefault(default)
    }
}
