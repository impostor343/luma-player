# Keep Room entities and kotlinx.serialization models
-keep class com.lumaplayer.app.data.db.** { *; }
-keep class com.lumaplayer.app.data.prefs.** { *; }
-keepattributes *Annotation*, InnerClasses
-dontwarn kotlinx.serialization.**
