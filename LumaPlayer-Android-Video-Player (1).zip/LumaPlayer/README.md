# LumaPlayer — Offline Android Video Player

**Target Device & Platform:** Motorola Edge 50, Android 16 (API 36), `minSdk = 29`  
**Stack:** Kotlin 2.1.21, Jetpack Compose + Material 3, AndroidX Media3 (ExoPlayer 1.8.0), Room 2.7.1 (KSP), DataStore Preferences 1.1.4.  
**Privacy:** Strictly offline — `AndroidManifest.xml` does **not** request `android.permission.INTERNET`, and there are zero ads, analytics, accounts, or telemetry SDKs.

## Key Capabilities

1. **Reliable Hardware-First Media3 Playback:** `SurfaceView`-backed `PlayerView` with hardware decoding by default, software fallback when available, audio focus & becoming-noisy handling, smooth rotation (`configChanges`), Picture-in-Picture, A-B repeat, sleep timer, and graceful error recovery.
2. **HDR / SDR Detection & Strict Mode:** Inspects actual Media3 `Format.colorInfo` and `MediaMetadataRetriever` metadata (never filename or resolution). Separates **Source Format** (`SDR`, `HDR10`, `HDR10+`, `HLG`, `DOLBY VISION`) from **Display Output Mode** (`Display.HdrCapabilities` & Android 14+ `Display.getHdrSdrRatio()`). Preserves HDR by default and never silently tone-maps to SDR unless the user explicitly enables HDR Compatibility Mode.
3. **Eye-Comfort Video Brightness & Normal-Brightness Subtitles:** `EyeComfortController` isolates video-surface brightness from HUD controls and subtitles. At high or maximum brightness (and during HDR playback), both HUD controls and Media3 `SubtitleView` text luminance are smoothly compensated so subtitles never look glaringly bright and always remain comfortable to read.
4. **Full Gesture Suite:** Tap to show/hide controls, double-tap left/right to seek, horizontal swipe seek, left-edge brightness, right-edge volume, pinch-to-zoom, and long-press temporary 2x playback speed that always restores the prior speed on release, cancel, interruption, or lifecycle pause.
5. **Automatic Library Scanning:** Discovers local videos via `MediaStore.Video.Media` and user-selected SAF folders (`DocumentFile`), generates real frame thumbnails via a memory-bounded `LruCache`, and marks deleted/missing files as unavailable without deleting playback history or reviews.
6. **Video Info & Per-Video Playback Logbook:** Press `i` on any video to view full technical details and every playback session (`Opened` / `Exited` actual clock times separated from `Started` / `Paused` / `Resumed` / `Completed` video timeline positions and active viewing time).
7. **Automatic Video Reviews & Folders:** Configurable near-completion triggers (default: final 10 min for >60 min videos, final 2 min for 20–60 min videos, 90% for <20 min videos), dismissal memory, 1–5 star ratings, written reviews, notes, tags, independent review folders (create, rename, delete, move, search, sort), and JSON backup export.
8. **Organized Settings & Player Lab:** 11 categorized settings pages plus **Player Lab** (Basic / Advanced / Expert modes, playback profiles, validated Media3 buffer & decoder tuning, restart-required notice, JSON import/export, restore defaults).

## Build & Installation Instructions

### Option 1: GitHub Actions (No Local Android Studio Required)
1. Unzip `LumaPlayer-Android-Video-Player.zip` and push the `LumaPlayer/` folder to a GitHub repository.
2. Open the **Actions** tab → **Build Android APK & Run Tests** → click **Run workflow** (or push to `main`).
3. Download the `LumaPlayer-debug-apk` artifact from the completed workflow run.
4. Transfer `app-debug.apk` to your Motorola Edge 50 and tap it to install (enable *Install unknown apps* if prompted).

### Option 2: Android Studio (Local Build)
1. Open the `LumaPlayer/` folder in Android Studio (Meerkat / Narwhal or newer with Android SDK Platform 36 installed).
2. Let Gradle sync (uses Gradle 8.13, AGP 8.10.1, JDK 17).
3. Connect your Motorola Edge 50 via USB debugging and click **Run**, or build via **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Honest Testing & Verification Status

- **Verified in build environment:** Static validation of all XML manifests/resources, zero `INTERNET` permission check, Kotlin package/structure consistency, and balanced syntax checks across all source and test files.
- **Not yet executed in this environment (offline sandbox without Android SDK/Gradle):**
  - Gradle compilation (`assembleDebug`) and JUnit execution (`testDebugUnitTest`) — ready to run via the included GitHub Actions workflow or Android Studio.
  - Physical device testing on Motorola Edge 50 (Android 16): actual hardware video rendering across MP4/MKV/HEVC/AV1/HDR10/HDR10+/HLG files, MediaStore/SAF scanning, gesture feel, PiP, rotation, and live HDR/SDR output verification.
